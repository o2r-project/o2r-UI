data<-read.table("example_data1.txt",sep="\t", header=TRUE)
Time <-as.POSIXct(strptime(data$Time,format="%Y.%m.%d %H:%M"))
N <- nrow(data)
FFT_Temperature <- fft(data$Temperature)/N  
threshold <- 0.1 # this can be measurement-specific ####
FFT_Tmain <- which(Mod(FFT_Temperature) > threshold) 
specs <- 1/(FFT_Tmain/N)   # period lengths of spectra selected by the threshold (T=1/f) [hour]
nspecs <- length(specs)
FFT_seasonal <- FFT_Tmain[which(specs>30*24 & specs<367*24)] # extracting seasonal component
FFT_seasonal <- append(FFT_seasonal, FFT_Tmain[nspecs-which(is.element(FFT_Tmain,FFT_seasonal))+2])  # also corresponding ones
FFT_Temperature_seasonal <- replace(FFT_Temperature,c(-FFT_seasonal),0)
Temperature_seasonal <- Re(fft(FFT_Temperature_seasonal, inverse=TRUE))
plot(Time, Temperature_seasonal, type="l", col="red", ylab="Seasonal")