data<-read.table("example_data1.txt",sep="\t", header=TRUE)
Time <-as.POSIXct(strptime(data$Time,format="%Y.%m.%d %H:%M"))
N <- nrow(data)
FFT_Temperature <- fft(data$Temperature)/N  
plot(Time, data$Temperature, type="l", col="black", ylab="Observed")