data<-read.table("example_data1.txt",sep="\t", header=TRUE)
Time <-as.POSIXct(strptime(data$Time,format="%Y.%m.%d %H:%M"))
N <- nrow(data)
FFT_Temperature <- fft(data$Temperature)/N  
threshold <- 0.1 # this can be measurement-specific ####
FFT_Tmain <- which(Mod(FFT_Temperature) > threshold) 
specs <- 1/(FFT_Tmain/N)   # period lengths of spectra selected by the threshold (T=1/f) [hour]
nspecs <- length(specs)
FFT_diel <- FFT_Tmain[which(specs>11 & specs<25)]              #  diel component
FFT_diel <- append(FFT_diel, FFT_Tmain[nspecs-which(is.element(FFT_Tmain,FFT_diel))+2])
FFT_Temperature_diel     <- replace(FFT_Temperature,c(-FFT_diel),0)
Temperature_diel     <- Re(fft(FFT_Temperature_diel,     inverse=TRUE))
plot(Time, Temperature_diel, type="l", col="red", ylab="Diel")