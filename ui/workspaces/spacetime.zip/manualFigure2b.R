  library(ggplot2)
  library("dplyr")
  library("latticeExtra")
  load("mjoBestUse.RData")
  Intensity  = newValue
  Tracks.df = filter(Tracks.df, Int >= Intensity) 
  fullData.df = load("best.use.2014.Rdata")
  begin = 1975; end = 2014
  fullData.df = best.use %>%
    mutate(Int = WmaxS * .5144, 
           DIntDt = DWmaxDt * .5144) %>%
    filter(Yr >= begin, Yr <= end, Int >= 33.0, M == FALSE)
  library("rgdal")
  ll = "+proj=longlat +ellps=WGS84"
  Tracks.sdf = Tracks.df
  coordinates(Tracks.sdf) = c("lon", "lat")
  proj4string(Tracks.sdf) = CRS(ll)
  fullData.sdf = fullData.df
  coordinates(fullData.sdf) = c("lon", "lat")
  proj4string(fullData.sdf) = CRS(ll)
  library("raster")
  r = raster(ncol = 10, nrow = 5, 
             xmn = -100, xmx = -20, 
             ymn = 10, ymx = 50)
  library("RColorBrewer")
  library("rasterVis")
  library(mapproj)
  library(maptools)
  outlines = as.data.frame(map("world", xlim = c(-100, -20), 
                               ylim = c(10, 50), 
                               plot = FALSE)[c("x", "y")],
                           color = "gray")
  map = geom_path(aes(x, y), inherit.aes = FALSE, data = outlines, 
                  alpha = .8, show_guide = FALSE, color = "blue")
  ext = as.vector(extent(r))
  boundaries = map("world", fill = TRUE, xlim = ext[1:2], 
                   ylim = ext[3:4], plot = FALSE)
  IDs = sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <<- map2SpatialPolygons(boundaries, IDs = IDs,
                                proj4string = CRS(projection(r)))
  require(gridExtra)
  require(sp)
  library(grid)
  library(wesanderson)
  Count.grid = rasterize(Tracks.sdf, r,
                         field = 'Sid',
                         fun = function(x,...) {length(unique(na.omit(x)))})
  fullCount.grid = rasterize(fullData.sdf, r,
                             field = 'Sid',
                             fun = function(x,...) {length(unique(na.omit(x)))})
  difCount.grid = Count.grid / fullCount.grid
  rng = seq(0.2, 1, 0.2)
  breaks =  c(0.2, 0.4, 0.6, 0.8, 1.0)
  cr = brewer.pal(5, "Blues")
  cr = cr[-(1)]
  vals = levelplot(difCount.grid, margin = FALSE,
                   sub=expression(paste("Ratio of intensifying hurricanes to all hurricanes")),
                   xlab = NULL, ylab = NULL, 
                   at=rng, col.regions = cr,
                   colorkey = list(space = 'bottom',    at=breaks,labels=list(at=breaks)),
                   border = "white", border.lwd = 2,
                   par.settings = list(fontsize=list(text=12)),
                   scales=list(draw=FALSE))
  pDif = vals + latticeExtra::layer(sp.polygons(bPols, col = gray(.8))) 
  pDif = update(pDif, main = textGrob("b", x = unit(.05, "npc"), 
                                      gp = gpar(fontsize=16)))
  plot(pDif)