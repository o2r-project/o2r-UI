library(ggplot2)
library("dplyr")
library("latticeExtra")
load("mjoBestUse.RData")

Tracks.df = filter(Tracks.df, Int >= 33.0) 

fullData.df = load("best.use.2014.Rdata")
begin = 1975; end = 2014

fullData.df = best.use %>%
  mutate(Int = WmaxS * .5144, 
         DIntDt = DWmaxDt * .5144) %>%
  filter(Yr >= begin, Yr <= end, Int >= 33.0, M == FALSE)

library("rgdal")
ll = "+proj=longlat +ellps=WGS84"

Tracks.sdf = Tracks.df
coordinates(Tracks.sdf) = c("lon", "lat")
proj4string(Tracks.sdf) = CRS(ll)

fullData.sdf = fullData.df
coordinates(fullData.sdf) = c("lon", "lat")
proj4string(fullData.sdf) = CRS(ll)

library("raster")
r = raster(ncol = 10, nrow = 5, 
           xmn = -100, xmx = -20, 
           ymn = 10, ymx = 50)

Tracks.grid = rasterize(Tracks.sdf, r,
                        field = 'DIntDt',
                        fun = mean)

Example.sdf = subset(Tracks.sdf, 
                     Sid == 1675 | 
                       Sid == 1677 |
                       Sid == 1683)
Example.grid = rasterize(Example.sdf, r, 
                         field = 'DIntDt',
                         fun = mean)

library("RColorBrewer")
library("rasterVis")
rng = seq(0, 1.5, 1.5)
breaks = c(0, 0.25, 0.50, 0.75, 1.0, 1.25, 1.50)
cr = brewer.pal(9, "Purples")
cr = cr[-(1:3)]
vals = levelplot(Example.grid, margin = FALSE, 
                 xlab = NULL, ylab = NULL, 
                 col.regions = cr, at = rng, 
                 colorkey = NULL,
                 border = "white", border.lwd = 2, pretty=TRUE,
                 par.settings = list(fontsize = list(text = 15)))

library(mapproj)
library(maptools)

outlines = as.data.frame(map("world", xlim = c(-100, -20), 
                             ylim = c(10, 50), 
                             plot = FALSE)[c("x", "y")],
                         color = "gray")
map = geom_path(aes(x, y), inherit.aes = FALSE, data = outlines, 
                alpha = .8, show_guide = FALSE, color = "blue")
ext = as.vector(extent(r))
boundaries = map("world", fill = TRUE, xlim = ext[1:2], 
                 ylim = ext[3:4], plot = FALSE)
IDs = sapply(strsplit(boundaries$names, ":"), function(x) x[1])
bPols <<- map2SpatialPolygons(boundaries, IDs = IDs,
                            proj4string = CRS(projection(r)))

data1975 = filter(Tracks.df, Yr == 1975)
data1975.sdf = data1975
coordinates(data1975.sdf) = c("lon", "lat")
proj4string(data1975.sdf) = CRS(ll)

data1975.grid = rasterize(data1975.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1976 = filter(Tracks.df, Yr == 1976)
data1976.sdf = data1976
coordinates(data1976.sdf) = c("lon", "lat")
proj4string(data1976.sdf) = CRS(ll)

data1976.grid = rasterize(data1976.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1977 = filter(Tracks.df, Yr == 1977)
data1977.sdf = data1977
coordinates(data1977.sdf) = c("lon", "lat")
proj4string(data1977.sdf) = CRS(ll)

data1977.grid = rasterize(data1977.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1978 = filter(Tracks.df, Yr == 1978)
data1978.sdf = data1978
coordinates(data1978.sdf) = c("lon", "lat")
proj4string(data1978.sdf) = CRS(ll)

data1978.grid = rasterize(data1978.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1979 = filter(Tracks.df, Yr == 1979)
data1979.sdf = data1979
coordinates(data1979.sdf) = c("lon", "lat")
proj4string(data1979.sdf) = CRS(ll)

data1979.grid = rasterize(data1979.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1980 = filter(Tracks.df, Yr == 1980)
data1980.sdf = data1980
coordinates(data1980.sdf) = c("lon", "lat")
proj4string(data1980.sdf) = CRS(ll)

data1980.grid = rasterize(data1980.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1981 = filter(Tracks.df, Yr == 1981)
data1981.sdf = data1981
coordinates(data1981.sdf) = c("lon", "lat")
proj4string(data1981.sdf) = CRS(ll)

data1981.grid = rasterize(data1981.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1982 = filter(Tracks.df, Yr == 1982)
data1982.sdf = data1982
coordinates(data1982.sdf) = c("lon", "lat")
proj4string(data1982.sdf) = CRS(ll)

data1982.grid = rasterize(data1982.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1983 = filter(Tracks.df, Yr == 1983)
data1983.sdf = data1983
coordinates(data1983.sdf) = c("lon", "lat")
proj4string(data1983.sdf) = CRS(ll)

data1983.grid = rasterize(data1983.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1984 = filter(Tracks.df, Yr == 1984)
data1984.sdf = data1984
coordinates(data1984.sdf) = c("lon", "lat")
proj4string(data1984.sdf) = CRS(ll)

data1984.grid = rasterize(data1984.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1985 = filter(Tracks.df, Yr == 1985)
data1985.sdf = data1985
coordinates(data1985.sdf) = c("lon", "lat")
proj4string(data1985.sdf) = CRS(ll)

data1985.grid = rasterize(data1985.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1986 = filter(Tracks.df, Yr == 1986)
data1986.sdf = data1986
coordinates(data1986.sdf) = c("lon", "lat")
proj4string(data1986.sdf) = CRS(ll)

data1986.grid = rasterize(data1986.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1987 = filter(Tracks.df, Yr == 1987)
data1987.sdf = data1987
coordinates(data1987.sdf) = c("lon", "lat")
proj4string(data1987.sdf) = CRS(ll)

data1987.grid = rasterize(data1987.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1988 = filter(Tracks.df, Yr == 1988)
data1988.sdf = data1988
coordinates(data1988.sdf) = c("lon", "lat")
proj4string(data1988.sdf) = CRS(ll)

data1988.grid = rasterize(data1988.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1989 = filter(Tracks.df, Yr == 1989)
data1989.sdf = data1989
coordinates(data1989.sdf) = c("lon", "lat")
proj4string(data1989.sdf) = CRS(ll)

data1989.grid = rasterize(data1989.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1990 = filter(Tracks.df, Yr == 1990)
data1990.sdf = data1990
coordinates(data1990.sdf) = c("lon", "lat")
proj4string(data1990.sdf) = CRS(ll)

data1990.grid = rasterize(data1990.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1991 = filter(Tracks.df, Yr == 1991)
data1991.sdf = data1991
coordinates(data1991.sdf) = c("lon", "lat")
proj4string(data1991.sdf) = CRS(ll)

data1991.grid = rasterize(data1991.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1992 = filter(Tracks.df, Yr == 1992)
data1992.sdf = data1992
coordinates(data1992.sdf) = c("lon", "lat")
proj4string(data1992.sdf) = CRS(ll)

data1992.grid = rasterize(data1992.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1993 = filter(Tracks.df, Yr == 1993)
data1993.sdf = data1993
coordinates(data1993.sdf) = c("lon", "lat")
proj4string(data1993.sdf) = CRS(ll)

data1993.grid = rasterize(data1993.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1994 = filter(Tracks.df, Yr == 1994)
data1994.sdf = data1994
coordinates(data1994.sdf) = c("lon", "lat")
proj4string(data1994.sdf) = CRS(ll)

data1994.grid = rasterize(data1994.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1995 = filter(Tracks.df, Yr == 1995)
data1995.sdf = data1995
coordinates(data1995.sdf) = c("lon", "lat")
proj4string(data1995.sdf) = CRS(ll)

data1995.grid = rasterize(data1995.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1996 = filter(Tracks.df, Yr == 1996)
data1996.sdf = data1996
coordinates(data1996.sdf) = c("lon", "lat")
proj4string(data1996.sdf) = CRS(ll)

data1996.grid = rasterize(data1996.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1997 = filter(Tracks.df, Yr == 1997)
data1997.sdf = data1997
coordinates(data1997.sdf) = c("lon", "lat")
proj4string(data1997.sdf) = CRS(ll)

data1997.grid = rasterize(data1997.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1998 = filter(Tracks.df, Yr == 1998)
data1998.sdf = data1998
coordinates(data1998.sdf) = c("lon", "lat")
proj4string(data1998.sdf) = CRS(ll)

data1998.grid = rasterize(data1998.sdf, r, 
                          field = 'Int',
                          fun = mean)

data1999 = filter(Tracks.df, Yr == 1999)
data1999.sdf = data1999
coordinates(data1999.sdf) = c("lon", "lat")
proj4string(data1999.sdf) = CRS(ll)

data1999.grid = rasterize(data1999.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2000 = filter(Tracks.df, Yr == 2000)
data2000.sdf = data2000
coordinates(data2000.sdf) = c("lon", "lat")
proj4string(data2000.sdf) = CRS(ll)

data2000.grid = rasterize(data2000.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2001 = filter(Tracks.df, Yr == 2001)
data2001.sdf = data2001
coordinates(data2001.sdf) = c("lon", "lat")
proj4string(data2001.sdf) = CRS(ll)

data2001.grid = rasterize(data2001.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2002 = filter(Tracks.df, Yr == 2002)
data2002.sdf = data2002
coordinates(data2002.sdf) = c("lon", "lat")
proj4string(data2002.sdf) = CRS(ll)

data2002.grid = rasterize(data2002.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2003 = filter(Tracks.df, Yr == 2003)
data2003.sdf = data2003
coordinates(data2003.sdf) = c("lon", "lat")
proj4string(data2003.sdf) = CRS(ll)

data2003.grid = rasterize(data2003.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2004 = filter(Tracks.df, Yr == 2004)
data2004.sdf = data2004
coordinates(data2004.sdf) = c("lon", "lat")
proj4string(data2004.sdf) = CRS(ll)

data2004.grid = rasterize(data2004.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2005 = filter(Tracks.df, Yr == 2005)
data2005.sdf = data2005
coordinates(data2005.sdf) = c("lon", "lat")
proj4string(data2005.sdf) = CRS(ll)

data2005.grid = rasterize(data2005.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2006 = filter(Tracks.df, Yr == 2006)
data2006.sdf = data2006
coordinates(data2006.sdf) = c("lon", "lat")
proj4string(data2006.sdf) = CRS(ll)

data2006.grid = rasterize(data2006.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2007 = filter(Tracks.df, Yr == 2007)
data2007.sdf = data2007
coordinates(data2007.sdf) = c("lon", "lat")
proj4string(data2007.sdf) = CRS(ll)

data2007.grid = rasterize(data2007.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2008 = filter(Tracks.df, Yr == 2008)
data2008.sdf = data2008
coordinates(data2008.sdf) = c("lon", "lat")
proj4string(data2008.sdf) = CRS(ll)

data2008.grid = rasterize(data2008.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2009 = filter(Tracks.df, Yr == 2009)
data2009.sdf = data2009
coordinates(data2009.sdf) = c("lon", "lat")
proj4string(data2009.sdf) = CRS(ll)

data2009.grid = rasterize(data2009.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2010 = filter(Tracks.df, Yr == 2010)
data2010.sdf = data2010
coordinates(data2010.sdf) = c("lon", "lat")
proj4string(data2010.sdf) = CRS(ll)

data2010.grid = rasterize(data2010.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2011 = filter(Tracks.df, Yr == 2011)
data2011.sdf = data2011
coordinates(data2011.sdf) = c("lon", "lat")
proj4string(data2011.sdf) = CRS(ll)

data2011.grid = rasterize(data2011.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2012 = filter(Tracks.df, Yr == 2012)
data2012.sdf = data2012
coordinates(data2012.sdf) = c("lon", "lat")
proj4string(data2012.sdf) = CRS(ll)

data2012.grid = rasterize(data2012.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2013 = filter(Tracks.df, Yr == 2013)
data2013.sdf = data2013
coordinates(data2013.sdf) = c("lon", "lat")
proj4string(data2013.sdf) = CRS(ll)

data2013.grid = rasterize(data2013.sdf, r, 
                          field = 'Int',
                          fun = mean)

data2014 = filter(Tracks.df, Yr == 2014)
data2014.sdf = data2014
coordinates(data2014.sdf) = c("lon", "lat")
proj4string(data2014.sdf) = CRS(ll)

data2014.grid = rasterize(data2014.sdf, r, 
                          field = 'Int',
                          fun = mean)

dataInt1975.df = as.data.frame(data1975.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1975.df) <- c("lon", "lat", "Int")
dataInt1976.df = as.data.frame(data1976.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1976.df) <- c("lon", "lat", "Int")
dataInt1977.df = as.data.frame(data1977.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1977.df) <- c("lon", "lat", "Int")
dataInt1978.df = as.data.frame(data1978.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1978.df) <- c("lon", "lat", "Int")
dataInt1979.df = as.data.frame(data1979.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1979.df) <- c("lon", "lat", "Int")
dataInt1980.df = as.data.frame(data1980.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1980.df) <- c("lon", "lat", "Int")
dataInt1981.df = as.data.frame(data1981.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1981.df) <- c("lon", "lat", "Int")
dataInt1982.df = as.data.frame(data1982.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1982.df) <- c("lon", "lat", "Int")
dataInt1983.df = as.data.frame(data1983.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1983.df) <- c("lon", "lat", "Int")
dataInt1984.df = as.data.frame(data1984.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1984.df) <- c("lon", "lat", "Int")
dataInt1985.df = as.data.frame(data1985.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1985.df) <- c("lon", "lat", "Int")
dataInt1986.df = as.data.frame(data1986.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1986.df) <- c("lon", "lat", "Int")
dataInt1987.df = as.data.frame(data1987.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1987.df) <- c("lon", "lat", "Int")
dataInt1988.df = as.data.frame(data1988.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1988.df) <- c("lon", "lat", "Int")
dataInt1989.df = as.data.frame(data1989.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1989.df) <- c("lon", "lat", "Int")
dataInt1990.df = as.data.frame(data1990.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1990.df) <- c("lon", "lat", "Int")
dataInt1991.df = as.data.frame(data1991.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1991.df) <- c("lon", "lat", "Int")
dataInt1992.df = as.data.frame(data1992.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1992.df) <- c("lon", "lat", "Int")
dataInt1993.df = as.data.frame(data1993.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1993.df) <- c("lon", "lat", "Int")
dataInt1994.df = as.data.frame(data1994.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1994.df) <- c("lon", "lat", "Int")
dataInt1995.df = as.data.frame(data1995.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1995.df) <- c("lon", "lat", "Int")
dataInt1996.df = as.data.frame(data1996.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1996.df) <- c("lon", "lat", "Int")
dataInt1997.df = as.data.frame(data1997.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1997.df) <- c("lon", "lat", "Int")
dataInt1998.df = as.data.frame(data1998.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1998.df) <- c("lon", "lat", "Int")
dataInt1999.df = as.data.frame(data1999.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1999.df) <- c("lon", "lat", "Int")
dataInt2000.df = as.data.frame(data2000.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2000.df) <- c("lon", "lat", "Int")
dataInt2001.df = as.data.frame(data2001.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2001.df) <- c("lon", "lat", "Int")
dataInt2002.df = as.data.frame(data2002.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2002.df) <- c("lon", "lat", "Int")
dataInt2003.df = as.data.frame(data2003.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2003.df) <- c("lon", "lat", "Int")
dataInt2004.df = as.data.frame(data2004.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2004.df) <- c("lon", "lat", "Int")
dataInt2005.df = as.data.frame(data2005.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2005.df) <- c("lon", "lat", "Int")
dataInt2006.df = as.data.frame(data2006.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2006.df) <- c("lon", "lat", "Int")
dataInt2007.df = as.data.frame(data2007.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2007.df) <- c("lon", "lat", "Int")
dataInt2008.df = as.data.frame(data2008.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2008.df) <- c("lon", "lat", "Int")
dataInt2009.df = as.data.frame(data2009.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2009.df) <- c("lon", "lat", "Int")
dataInt2010.df = as.data.frame(data2010.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2010.df) <- c("lon", "lat", "Int")
dataInt2011.df = as.data.frame(data2011.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2011.df) <- c("lon", "lat", "Int")
dataInt2012.df = as.data.frame(data2012.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2012.df) <- c("lon", "lat", "Int")
dataInt2013.df = as.data.frame(data2013.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2013.df) <- c("lon", "lat", "Int")
dataInt2014.df = as.data.frame(data2014.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2014.df) <- c("lon", "lat", "Int")

dataInt1975.df$Year[1:50] = 1975
dataInt1976.df$Year[1:50] = 1976
dataInt1977.df$Year[1:50] = 1977
dataInt1978.df$Year[1:50] = 1978
dataInt1979.df$Year[1:50] = 1979
dataInt1980.df$Year[1:50] = 1980
dataInt1981.df$Year[1:50] = 1981
dataInt1982.df$Year[1:50] = 1982
dataInt1983.df$Year[1:50] = 1983
dataInt1984.df$Year[1:50] = 1984
dataInt1985.df$Year[1:50] = 1985
dataInt1986.df$Year[1:50] = 1986
dataInt1987.df$Year[1:50] = 1987
dataInt1988.df$Year[1:50] = 1988
dataInt1989.df$Year[1:50] = 1989
dataInt1990.df$Year[1:50] = 1990
dataInt1991.df$Year[1:50] = 1991
dataInt1992.df$Year[1:50] = 1992
dataInt1993.df$Year[1:50] = 1993
dataInt1994.df$Year[1:50] = 1994
dataInt1995.df$Year[1:50] = 1995
dataInt1996.df$Year[1:50] = 1996
dataInt1997.df$Year[1:50] = 1997
dataInt1998.df$Year[1:50] = 1998
dataInt1999.df$Year[1:50] = 1999
dataInt2000.df$Year[1:50] = 2000
dataInt2001.df$Year[1:50] = 2001
dataInt2002.df$Year[1:50] = 2002
dataInt2003.df$Year[1:50] = 2003
dataInt2004.df$Year[1:50] = 2004
dataInt2005.df$Year[1:50] = 2005
dataInt2006.df$Year[1:50] = 2006
dataInt2007.df$Year[1:50] = 2007
dataInt2008.df$Year[1:50] = 2008
dataInt2009.df$Year[1:50] = 2009
dataInt2010.df$Year[1:50] = 2010
dataInt2011.df$Year[1:50] = 2011
dataInt2012.df$Year[1:50] = 2012
dataInt2013.df$Year[1:50] = 2013
dataInt2014.df$Year[1:50] = 2014

dataInt1975.df$ID = as.numeric(as.factor(with(dataInt1975.df, paste(lon, lat,  sep="_"))))
dataInt1976.df$ID = as.numeric(as.factor(with(dataInt1976.df, paste(lon, lat,  sep="_"))))
dataInt1977.df$ID = as.numeric(as.factor(with(dataInt1977.df, paste(lon, lat,  sep="_"))))
dataInt1978.df$ID = as.numeric(as.factor(with(dataInt1978.df, paste(lon, lat,  sep="_"))))
dataInt1979.df$ID = as.numeric(as.factor(with(dataInt1979.df, paste(lon, lat,  sep="_"))))
dataInt1980.df$ID = as.numeric(as.factor(with(dataInt1980.df, paste(lon, lat,  sep="_"))))
dataInt1981.df$ID = as.numeric(as.factor(with(dataInt1981.df, paste(lon, lat,  sep="_"))))
dataInt1982.df$ID = as.numeric(as.factor(with(dataInt1982.df, paste(lon, lat,  sep="_"))))
dataInt1983.df$ID = as.numeric(as.factor(with(dataInt1983.df, paste(lon, lat,  sep="_"))))
dataInt1984.df$ID = as.numeric(as.factor(with(dataInt1984.df, paste(lon, lat,  sep="_"))))
dataInt1985.df$ID = as.numeric(as.factor(with(dataInt1985.df, paste(lon, lat,  sep="_"))))
dataInt1986.df$ID = as.numeric(as.factor(with(dataInt1986.df, paste(lon, lat,  sep="_"))))
dataInt1987.df$ID = as.numeric(as.factor(with(dataInt1987.df, paste(lon, lat,  sep="_"))))
dataInt1988.df$ID = as.numeric(as.factor(with(dataInt1988.df, paste(lon, lat,  sep="_"))))
dataInt1989.df$ID = as.numeric(as.factor(with(dataInt1989.df, paste(lon, lat,  sep="_"))))
dataInt1990.df$ID = as.numeric(as.factor(with(dataInt1990.df, paste(lon, lat,  sep="_"))))
dataInt1991.df$ID = as.numeric(as.factor(with(dataInt1991.df, paste(lon, lat,  sep="_"))))
dataInt1992.df$ID = as.numeric(as.factor(with(dataInt1992.df, paste(lon, lat,  sep="_"))))
dataInt1993.df$ID = as.numeric(as.factor(with(dataInt1993.df, paste(lon, lat,  sep="_"))))
dataInt1994.df$ID = as.numeric(as.factor(with(dataInt1994.df, paste(lon, lat,  sep="_"))))
dataInt1995.df$ID = as.numeric(as.factor(with(dataInt1995.df, paste(lon, lat,  sep="_"))))
dataInt1996.df$ID = as.numeric(as.factor(with(dataInt1996.df, paste(lon, lat,  sep="_"))))
dataInt1997.df$ID = as.numeric(as.factor(with(dataInt1997.df, paste(lon, lat,  sep="_"))))
dataInt1998.df$ID = as.numeric(as.factor(with(dataInt1998.df, paste(lon, lat,  sep="_"))))
dataInt1999.df$ID = as.numeric(as.factor(with(dataInt1999.df, paste(lon, lat,  sep="_"))))
dataInt2000.df$ID = as.numeric(as.factor(with(dataInt2000.df, paste(lon, lat,  sep="_"))))
dataInt2001.df$ID = as.numeric(as.factor(with(dataInt2001.df, paste(lon, lat,  sep="_"))))
dataInt2002.df$ID = as.numeric(as.factor(with(dataInt2002.df, paste(lon, lat,  sep="_"))))
dataInt2003.df$ID = as.numeric(as.factor(with(dataInt2003.df, paste(lon, lat,  sep="_"))))
dataInt2004.df$ID = as.numeric(as.factor(with(dataInt2004.df, paste(lon, lat,  sep="_"))))
dataInt2005.df$ID = as.numeric(as.factor(with(dataInt2005.df, paste(lon, lat,  sep="_"))))
dataInt2006.df$ID = as.numeric(as.factor(with(dataInt2006.df, paste(lon, lat,  sep="_"))))
dataInt2007.df$ID = as.numeric(as.factor(with(dataInt2007.df, paste(lon, lat,  sep="_"))))
dataInt2008.df$ID = as.numeric(as.factor(with(dataInt2008.df, paste(lon, lat,  sep="_"))))
dataInt2009.df$ID = as.numeric(as.factor(with(dataInt2009.df, paste(lon, lat,  sep="_"))))
dataInt2010.df$ID = as.numeric(as.factor(with(dataInt2010.df, paste(lon, lat,  sep="_"))))
dataInt2011.df$ID = as.numeric(as.factor(with(dataInt2011.df, paste(lon, lat,  sep="_"))))
dataInt2012.df$ID = as.numeric(as.factor(with(dataInt2012.df, paste(lon, lat,  sep="_"))))
dataInt2013.df$ID = as.numeric(as.factor(with(dataInt2013.df, paste(lon, lat,  sep="_"))))
dataInt2014.df$ID = as.numeric(as.factor(with(dataInt2014.df, paste(lon, lat,  sep="_"))))

Intensity = rbind(dataInt1975.df,dataInt1976.df, dataInt1977.df, dataInt1978.df, dataInt1979.df,
                  dataInt1980.df, dataInt1981.df, dataInt1982.df, dataInt1983.df,
                  dataInt1984.df, dataInt1985.df, dataInt1986.df, dataInt1987.df,
                  dataInt1988.df, dataInt1989.df, dataInt1990.df, dataInt1991.df, 
                  dataInt1992.df, dataInt1993.df, dataInt1994.df, dataInt1995.df, 
                  dataInt1996.df, dataInt1997.df, dataInt1998.df, dataInt1999.df,
                  dataInt2000.df, dataInt2001.df, dataInt2002.df, dataInt2003.df,
                  dataInt2004.df, dataInt2005.df, dataInt2006.df, dataInt2007.df,
                  dataInt2008.df, dataInt2009.df, dataInt2010.df, dataInt2011.df,
                  dataInt2012.df, dataInt2013.df, dataInt2014.df) 

Intensity$ID = as.integer(Intensity$ID)

looper = nrow(Intensity)

while(looper > 0)
{
  if ((Intensity$ID[looper] == 50) == TRUE | (Intensity$ID[looper] == 46) == TRUE |
      (Intensity$ID[looper] == 45) == TRUE | (Intensity$ID[looper] == 35) == TRUE |
      (Intensity$ID[looper] == 49) == TRUE | (Intensity$ID[looper] == 40) == TRUE|
      (Intensity$ID[looper] == 44) == TRUE | (Intensity$ID[looper] == 3) == TRUE |
      (Intensity$ID[looper] == 4) == TRUE)
  {
    Intensity = Intensity[-looper,]
  }
  looper = looper - 1
}

ID = dataInt1975.df$ID
Yr = c(1975:2014)

IntData.df = data.frame(ID)

IntData.df = cbind(IntData.df, dataInt1975.df$Int)
IntData.df = cbind(IntData.df, dataInt1976.df$Int)
IntData.df = cbind(IntData.df, dataInt1977.df$Int)
IntData.df = cbind(IntData.df, dataInt1978.df$Int)
IntData.df = cbind(IntData.df, dataInt1979.df$Int)
IntData.df = cbind(IntData.df, dataInt1980.df$Int)
IntData.df = cbind(IntData.df, dataInt1981.df$Int)
IntData.df = cbind(IntData.df, dataInt1982.df$Int)
IntData.df = cbind(IntData.df, dataInt1983.df$Int)
IntData.df = cbind(IntData.df, dataInt1984.df$Int)
IntData.df = cbind(IntData.df, dataInt1985.df$Int)
IntData.df = cbind(IntData.df, dataInt1986.df$Int)
IntData.df = cbind(IntData.df, dataInt1987.df$Int)
IntData.df = cbind(IntData.df, dataInt1988.df$Int)
IntData.df = cbind(IntData.df, dataInt1989.df$Int)
IntData.df = cbind(IntData.df, dataInt1990.df$Int)
IntData.df = cbind(IntData.df, dataInt1991.df$Int)
IntData.df = cbind(IntData.df, dataInt1992.df$Int)
IntData.df = cbind(IntData.df, dataInt1993.df$Int)
IntData.df = cbind(IntData.df, dataInt1994.df$Int)
IntData.df = cbind(IntData.df, dataInt1995.df$Int)
IntData.df = cbind(IntData.df, dataInt1996.df$Int)
IntData.df = cbind(IntData.df, dataInt1997.df$Int)
IntData.df = cbind(IntData.df, dataInt1998.df$Int)
IntData.df = cbind(IntData.df, dataInt1999.df$Int)
IntData.df = cbind(IntData.df, dataInt2000.df$Int)
IntData.df = cbind(IntData.df, dataInt2001.df$Int)
IntData.df = cbind(IntData.df, dataInt2002.df$Int)
IntData.df = cbind(IntData.df, dataInt2003.df$Int)
IntData.df = cbind(IntData.df, dataInt2004.df$Int)
IntData.df = cbind(IntData.df, dataInt2005.df$Int)
IntData.df = cbind(IntData.df, dataInt2006.df$Int)
IntData.df = cbind(IntData.df, dataInt2007.df$Int)
IntData.df = cbind(IntData.df, dataInt2008.df$Int)
IntData.df = cbind(IntData.df, dataInt2009.df$Int)
IntData.df = cbind(IntData.df, dataInt2010.df$Int)
IntData.df = cbind(IntData.df, dataInt2011.df$Int)
IntData.df = cbind(IntData.df, dataInt2012.df$Int)
IntData.df = cbind(IntData.df, dataInt2013.df$Int)
IntData.df = cbind(IntData.df, dataInt2014.df$Int)

x = 1
while (x < 41){
  colnames(IntData.df)[x+1] = Yr[x]
  x = x+1
}

IntData.df$ID = as.integer(IntData.df$ID)

looper = nrow(IntData.df)

while(looper > 0)
{
  if ((IntData.df$ID[looper] == 50) == TRUE | (IntData.df$ID[looper] == 46) == TRUE |
      (IntData.df$ID[looper] == 45) == TRUE | (IntData.df$ID[looper] == 35) == TRUE |
      (IntData.df$ID[looper] == 49) == TRUE | (IntData.df$ID[looper] == 40) == TRUE|
      (IntData.df$ID[looper] == 44) == TRUE | (IntData.df$ID[looper] == 3) == TRUE |
      (IntData.df$ID[looper] == 4) == TRUE)
  {
    IntData.df = IntData.df[-looper,]
  }
  looper = looper - 1
}

IntStack = stack(data1975.grid, data1976.grid, data1977.grid, data1978.grid, data1979.grid, data1980.grid,
                 data1981.grid, data1982.grid, data1983.grid, data1984.grid, data1985.grid,
                 data1986.grid, data1987.grid, data1988.grid, data1989.grid, data1990.grid,
                 data1991.grid, data1992.grid, data1993.grid, data1994.grid, data1995.grid,
                 data1996.grid, data1997.grid, data1998.grid, data1999.grid, data2000.grid,
                 data2001.grid, data2002.grid, data2003.grid, data2004.grid, data2005.grid,
                 data2006.grid, data2007.grid, data2008.grid, data2009.grid, data2010.grid,
                 data2011.grid, data2012.grid, data2013.grid, data2014.grid)

cr = brewer.pal(7, "Greens")
cr = cr[-(1)]
rng = seq(30, 84, 9)
breaks =  c(30, 39, 48, 57, 66, 75, 84 )

names = c('1975', '1976', '1977', '1978', '1979', '1980', '1981', '1982', '1983', '1984','1985', '1986', '1987', '1988', '1989', '1990', '1991', '1992', '1993',
          '1994', '1995', '1996', '1997', '1998', '1999', '2000', '2001', '2002',
          '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011',
          '2012', '2013', '2014')

plotting = spplot(IntStack, col.regions=cr, names.attr = names, 
                  at = rng, colorkey = list(space="bottom", at=breaks, labels=list(at=breaks)), labels=paste(rng),
                  par.settings=list(fontsize=list(text=10)),
                  sub=expression(paste("Intensity [m ", s^-1, "]")),
                  pretty=TRUE)

p2 = plotting + latticeExtra::layer(sp.polygons(bPols))
plot(p2)
