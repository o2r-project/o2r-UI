library(ggplot2)
library("dplyr")
library("latticeExtra")
load("mjoBestUse.RData")

Tracks.df = filter(Tracks.df, Int >= 33.0) 

library("rgdal")
ll = "+proj=longlat +ellps=WGS84"

Tracks.sdf = Tracks.df
coordinates(Tracks.sdf) = c("lon", "lat")
proj4string(Tracks.sdf) = CRS(ll)

library("raster")
r = raster(ncol = 10, nrow = 5, 
           xmn = -100, xmx = -20, 
           ymn = 10, ymx = 50)

Tracks.grid = rasterize(Tracks.sdf, r,
                        field = 'DIntDt',
                        fun = mean)

library("RColorBrewer")
library("rasterVis")

library(mapproj)
library(maptools)

require(gridExtra)
require(sp)

data1975 = filter(Tracks.df, Yr == 1975)
data1975.sdf = data1975
coordinates(data1975.sdf) = c("lon", "lat")
proj4string(data1975.sdf) = CRS(ll)

data1975.grid = rasterize(data1975.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1976 = filter(Tracks.df, Yr == 1976)
data1976.sdf = data1976
coordinates(data1976.sdf) = c("lon", "lat")
proj4string(data1976.sdf) = CRS(ll)

data1976.grid = rasterize(data1976.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1977 = filter(Tracks.df, Yr == 1977)
data1977.sdf = data1977
coordinates(data1977.sdf) = c("lon", "lat")
proj4string(data1977.sdf) = CRS(ll)

data1977.grid = rasterize(data1977.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1978 = filter(Tracks.df, Yr == 1978)
data1978.sdf = data1978
coordinates(data1978.sdf) = c("lon", "lat")
proj4string(data1978.sdf) = CRS(ll)

data1978.grid = rasterize(data1978.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1979 = filter(Tracks.df, Yr == 1979)
data1979.sdf = data1979
coordinates(data1979.sdf) = c("lon", "lat")
proj4string(data1979.sdf) = CRS(ll)

data1979.grid = rasterize(data1979.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1980 = filter(Tracks.df, Yr == 1980)
data1980.sdf = data1980
coordinates(data1980.sdf) = c("lon", "lat")
proj4string(data1980.sdf) = CRS(ll)

data1980.grid = rasterize(data1980.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1981 = filter(Tracks.df, Yr == 1981)
data1981.sdf = data1981
coordinates(data1981.sdf) = c("lon", "lat")
proj4string(data1981.sdf) = CRS(ll)

data1981.grid = rasterize(data1981.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1982 = filter(Tracks.df, Yr == 1982)
data1982.sdf = data1982
coordinates(data1982.sdf) = c("lon", "lat")
proj4string(data1982.sdf) = CRS(ll)

data1982.grid = rasterize(data1982.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1983 = filter(Tracks.df, Yr == 1983)
data1983.sdf = data1983
coordinates(data1983.sdf) = c("lon", "lat")
proj4string(data1983.sdf) = CRS(ll)

data1983.grid = rasterize(data1983.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1984 = filter(Tracks.df, Yr == 1984)
data1984.sdf = data1984
coordinates(data1984.sdf) = c("lon", "lat")
proj4string(data1984.sdf) = CRS(ll)

data1984.grid = rasterize(data1984.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1985 = filter(Tracks.df, Yr == 1985)
data1985.sdf = data1985
coordinates(data1985.sdf) = c("lon", "lat")
proj4string(data1985.sdf) = CRS(ll)

data1985.grid = rasterize(data1985.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1986 = filter(Tracks.df, Yr == 1986)
data1986.sdf = data1986
coordinates(data1986.sdf) = c("lon", "lat")
proj4string(data1986.sdf) = CRS(ll)

data1986.grid = rasterize(data1986.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1987 = filter(Tracks.df, Yr == 1987)
data1987.sdf = data1987
coordinates(data1987.sdf) = c("lon", "lat")
proj4string(data1987.sdf) = CRS(ll)

data1987.grid = rasterize(data1987.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1988 = filter(Tracks.df, Yr == 1988)
data1988.sdf = data1988
coordinates(data1988.sdf) = c("lon", "lat")
proj4string(data1988.sdf) = CRS(ll)

data1988.grid = rasterize(data1988.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1989 = filter(Tracks.df, Yr == 1989)
data1989.sdf = data1989
coordinates(data1989.sdf) = c("lon", "lat")
proj4string(data1989.sdf) = CRS(ll)

data1989.grid = rasterize(data1989.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1990 = filter(Tracks.df, Yr == 1990)
data1990.sdf = data1990
coordinates(data1990.sdf) = c("lon", "lat")
proj4string(data1990.sdf) = CRS(ll)

data1990.grid = rasterize(data1990.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1991 = filter(Tracks.df, Yr == 1991)
data1991.sdf = data1991
coordinates(data1991.sdf) = c("lon", "lat")
proj4string(data1991.sdf) = CRS(ll)

data1991.grid = rasterize(data1991.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1992 = filter(Tracks.df, Yr == 1992)
data1992.sdf = data1992
coordinates(data1992.sdf) = c("lon", "lat")
proj4string(data1992.sdf) = CRS(ll)

data1992.grid = rasterize(data1992.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1993 = filter(Tracks.df, Yr == 1993)
data1993.sdf = data1993
coordinates(data1993.sdf) = c("lon", "lat")
proj4string(data1993.sdf) = CRS(ll)

data1993.grid = rasterize(data1993.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1994 = filter(Tracks.df, Yr == 1994)
data1994.sdf = data1994
coordinates(data1994.sdf) = c("lon", "lat")
proj4string(data1994.sdf) = CRS(ll)

data1994.grid = rasterize(data1994.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1995 = filter(Tracks.df, Yr == 1995)
data1995.sdf = data1995
coordinates(data1995.sdf) = c("lon", "lat")
proj4string(data1995.sdf) = CRS(ll)

data1995.grid = rasterize(data1995.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1996 = filter(Tracks.df, Yr == 1996)
data1996.sdf = data1996
coordinates(data1996.sdf) = c("lon", "lat")
proj4string(data1996.sdf) = CRS(ll)

data1996.grid = rasterize(data1996.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1997 = filter(Tracks.df, Yr == 1997)
data1997.sdf = data1997
coordinates(data1997.sdf) = c("lon", "lat")
proj4string(data1997.sdf) = CRS(ll)

data1997.grid = rasterize(data1997.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1998 = filter(Tracks.df, Yr == 1998)
data1998.sdf = data1998
coordinates(data1998.sdf) = c("lon", "lat")
proj4string(data1998.sdf) = CRS(ll)

data1998.grid = rasterize(data1998.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data1999 = filter(Tracks.df, Yr == 1999)
data1999.sdf = data1999
coordinates(data1999.sdf) = c("lon", "lat")
proj4string(data1999.sdf) = CRS(ll)

data1999.grid = rasterize(data1999.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2000 = filter(Tracks.df, Yr == 2000)
data2000.sdf = data2000
coordinates(data2000.sdf) = c("lon", "lat")
proj4string(data2000.sdf) = CRS(ll)

data2000.grid = rasterize(data2000.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2001 = filter(Tracks.df, Yr == 2001)
data2001.sdf = data2001
coordinates(data2001.sdf) = c("lon", "lat")
proj4string(data2001.sdf) = CRS(ll)

data2001.grid = rasterize(data2001.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2002 = filter(Tracks.df, Yr == 2002)
data2002.sdf = data2002
coordinates(data2002.sdf) = c("lon", "lat")
proj4string(data2002.sdf) = CRS(ll)

data2002.grid = rasterize(data2002.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2003 = filter(Tracks.df, Yr == 2003)
data2003.sdf = data2003
coordinates(data2003.sdf) = c("lon", "lat")
proj4string(data2003.sdf) = CRS(ll)

data2003.grid = rasterize(data2003.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2004 = filter(Tracks.df, Yr == 2004)
data2004.sdf = data2004
coordinates(data2004.sdf) = c("lon", "lat")
proj4string(data2004.sdf) = CRS(ll)

data2004.grid = rasterize(data2004.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2005 = filter(Tracks.df, Yr == 2005)
data2005.sdf = data2005
coordinates(data2005.sdf) = c("lon", "lat")
proj4string(data2005.sdf) = CRS(ll)

data2005.grid = rasterize(data2005.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2006 = filter(Tracks.df, Yr == 2006)
data2006.sdf = data2006
coordinates(data2006.sdf) = c("lon", "lat")
proj4string(data2006.sdf) = CRS(ll)

data2006.grid = rasterize(data2006.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2007 = filter(Tracks.df, Yr == 2007)
data2007.sdf = data2007
coordinates(data2007.sdf) = c("lon", "lat")
proj4string(data2007.sdf) = CRS(ll)

data2007.grid = rasterize(data2007.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2008 = filter(Tracks.df, Yr == 2008)
data2008.sdf = data2008
coordinates(data2008.sdf) = c("lon", "lat")
proj4string(data2008.sdf) = CRS(ll)

data2008.grid = rasterize(data2008.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2009 = filter(Tracks.df, Yr == 2009)
data2009.sdf = data2009
coordinates(data2009.sdf) = c("lon", "lat")
proj4string(data2009.sdf) = CRS(ll)

data2009.grid = rasterize(data2009.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2010 = filter(Tracks.df, Yr == 2010)
data2010.sdf = data2010
coordinates(data2010.sdf) = c("lon", "lat")
proj4string(data2010.sdf) = CRS(ll)

data2010.grid = rasterize(data2010.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2011 = filter(Tracks.df, Yr == 2011)
data2011.sdf = data2011
coordinates(data2011.sdf) = c("lon", "lat")
proj4string(data2011.sdf) = CRS(ll)

data2011.grid = rasterize(data2011.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2012 = filter(Tracks.df, Yr == 2012)
data2012.sdf = data2012
coordinates(data2012.sdf) = c("lon", "lat")
proj4string(data2012.sdf) = CRS(ll)

data2012.grid = rasterize(data2012.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2013 = filter(Tracks.df, Yr == 2013)
data2013.sdf = data2013
coordinates(data2013.sdf) = c("lon", "lat")
proj4string(data2013.sdf) = CRS(ll)

data2013.grid = rasterize(data2013.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

data2014 = filter(Tracks.df, Yr == 2014)
data2014.sdf = data2014
coordinates(data2014.sdf) = c("lon", "lat")
proj4string(data2014.sdf) = CRS(ll)

data2014.grid = rasterize(data2014.sdf, r, 
                          field = 'DIntDt',
                          fun = mean)

dataDIntDt1975.df = as.data.frame(data1975.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1975.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1976.df = as.data.frame(data1976.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1976.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1977.df = as.data.frame(data1977.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1977.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1978.df = as.data.frame(data1978.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1978.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1979.df = as.data.frame(data1979.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1979.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1980.df = as.data.frame(data1980.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1980.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1981.df = as.data.frame(data1981.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1981.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1982.df = as.data.frame(data1982.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1982.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1983.df = as.data.frame(data1983.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1983.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1984.df = as.data.frame(data1984.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1984.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1985.df = as.data.frame(data1985.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1985.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1986.df = as.data.frame(data1986.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1986.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1987.df = as.data.frame(data1987.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1987.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1988.df = as.data.frame(data1988.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1988.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1989.df = as.data.frame(data1989.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1989.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1990.df = as.data.frame(data1990.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1990.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1991.df = as.data.frame(data1991.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1991.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1992.df = as.data.frame(data1992.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1992.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1993.df = as.data.frame(data1993.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1993.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1994.df = as.data.frame(data1994.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1994.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1995.df = as.data.frame(data1995.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1995.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1996.df = as.data.frame(data1996.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1996.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1997.df = as.data.frame(data1997.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1997.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1998.df = as.data.frame(data1998.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1998.df) <- c("lon", "lat", "DIntDt")
dataDIntDt1999.df = as.data.frame(data1999.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt1999.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2000.df = as.data.frame(data2000.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2000.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2001.df = as.data.frame(data2001.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2001.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2002.df = as.data.frame(data2002.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2002.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2003.df = as.data.frame(data2003.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2003.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2004.df = as.data.frame(data2004.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2004.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2005.df = as.data.frame(data2005.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2005.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2006.df = as.data.frame(data2006.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2006.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2007.df = as.data.frame(data2007.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2007.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2008.df = as.data.frame(data2008.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2008.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2009.df = as.data.frame(data2009.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2009.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2010.df = as.data.frame(data2010.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2010.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2011.df = as.data.frame(data2011.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2011.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2012.df = as.data.frame(data2012.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2012.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2013.df = as.data.frame(data2013.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2013.df) <- c("lon", "lat", "DIntDt")
dataDIntDt2014.df = as.data.frame(data2014.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataDIntDt2014.df) <- c("lon", "lat", "DIntDt")

dataDIntDt1975.df$Year[1:50] = 1975
dataDIntDt1976.df$Year[1:50] = 1976
dataDIntDt1977.df$Year[1:50] = 1977
dataDIntDt1978.df$Year[1:50] = 1978
dataDIntDt1979.df$Year[1:50] = 1979
dataDIntDt1980.df$Year[1:50] = 1980
dataDIntDt1981.df$Year[1:50] = 1981
dataDIntDt1982.df$Year[1:50] = 1982
dataDIntDt1983.df$Year[1:50] = 1983
dataDIntDt1984.df$Year[1:50] = 1984
dataDIntDt1985.df$Year[1:50] = 1985
dataDIntDt1986.df$Year[1:50] = 1986
dataDIntDt1987.df$Year[1:50] = 1987
dataDIntDt1988.df$Year[1:50] = 1988
dataDIntDt1989.df$Year[1:50] = 1989
dataDIntDt1990.df$Year[1:50] = 1990
dataDIntDt1991.df$Year[1:50] = 1991
dataDIntDt1992.df$Year[1:50] = 1992
dataDIntDt1993.df$Year[1:50] = 1993
dataDIntDt1994.df$Year[1:50] = 1994
dataDIntDt1995.df$Year[1:50] = 1995
dataDIntDt1996.df$Year[1:50] = 1996
dataDIntDt1997.df$Year[1:50] = 1997
dataDIntDt1998.df$Year[1:50] = 1998
dataDIntDt1999.df$Year[1:50] = 1999
dataDIntDt2000.df$Year[1:50] = 2000
dataDIntDt2001.df$Year[1:50] = 2001
dataDIntDt2002.df$Year[1:50] = 2002
dataDIntDt2003.df$Year[1:50] = 2003
dataDIntDt2004.df$Year[1:50] = 2004
dataDIntDt2005.df$Year[1:50] = 2005
dataDIntDt2006.df$Year[1:50] = 2006
dataDIntDt2007.df$Year[1:50] = 2007
dataDIntDt2008.df$Year[1:50] = 2008
dataDIntDt2009.df$Year[1:50] = 2009
dataDIntDt2010.df$Year[1:50] = 2010
dataDIntDt2011.df$Year[1:50] = 2011
dataDIntDt2012.df$Year[1:50] = 2012
dataDIntDt2013.df$Year[1:50] = 2013
dataDIntDt2014.df$Year[1:50] = 2014

dataDIntDt1975.df$ID = as.numeric(as.factor(with(dataDIntDt1975.df, paste(lon, lat,  sep="_"))))
dataDIntDt1976.df$ID = as.numeric(as.factor(with(dataDIntDt1976.df, paste(lon, lat,  sep="_"))))
dataDIntDt1977.df$ID = as.numeric(as.factor(with(dataDIntDt1977.df, paste(lon, lat,  sep="_"))))
dataDIntDt1978.df$ID = as.numeric(as.factor(with(dataDIntDt1978.df, paste(lon, lat,  sep="_"))))
dataDIntDt1979.df$ID = as.numeric(as.factor(with(dataDIntDt1979.df, paste(lon, lat,  sep="_"))))
dataDIntDt1980.df$ID = as.numeric(as.factor(with(dataDIntDt1980.df, paste(lon, lat,  sep="_"))))
dataDIntDt1981.df$ID = as.numeric(as.factor(with(dataDIntDt1981.df, paste(lon, lat,  sep="_"))))
dataDIntDt1982.df$ID = as.numeric(as.factor(with(dataDIntDt1982.df, paste(lon, lat,  sep="_"))))
dataDIntDt1983.df$ID = as.numeric(as.factor(with(dataDIntDt1983.df, paste(lon, lat,  sep="_"))))
dataDIntDt1984.df$ID = as.numeric(as.factor(with(dataDIntDt1984.df, paste(lon, lat,  sep="_"))))
dataDIntDt1985.df$ID = as.numeric(as.factor(with(dataDIntDt1985.df, paste(lon, lat,  sep="_"))))
dataDIntDt1986.df$ID = as.numeric(as.factor(with(dataDIntDt1986.df, paste(lon, lat,  sep="_"))))
dataDIntDt1987.df$ID = as.numeric(as.factor(with(dataDIntDt1987.df, paste(lon, lat,  sep="_"))))
dataDIntDt1988.df$ID = as.numeric(as.factor(with(dataDIntDt1988.df, paste(lon, lat,  sep="_"))))
dataDIntDt1989.df$ID = as.numeric(as.factor(with(dataDIntDt1989.df, paste(lon, lat,  sep="_"))))
dataDIntDt1990.df$ID = as.numeric(as.factor(with(dataDIntDt1990.df, paste(lon, lat,  sep="_"))))
dataDIntDt1991.df$ID = as.numeric(as.factor(with(dataDIntDt1991.df, paste(lon, lat,  sep="_"))))
dataDIntDt1992.df$ID = as.numeric(as.factor(with(dataDIntDt1992.df, paste(lon, lat,  sep="_"))))
dataDIntDt1993.df$ID = as.numeric(as.factor(with(dataDIntDt1993.df, paste(lon, lat,  sep="_"))))
dataDIntDt1994.df$ID = as.numeric(as.factor(with(dataDIntDt1994.df, paste(lon, lat,  sep="_"))))
dataDIntDt1995.df$ID = as.numeric(as.factor(with(dataDIntDt1995.df, paste(lon, lat,  sep="_"))))
dataDIntDt1996.df$ID = as.numeric(as.factor(with(dataDIntDt1996.df, paste(lon, lat,  sep="_"))))
dataDIntDt1997.df$ID = as.numeric(as.factor(with(dataDIntDt1997.df, paste(lon, lat,  sep="_"))))
dataDIntDt1998.df$ID = as.numeric(as.factor(with(dataDIntDt1998.df, paste(lon, lat,  sep="_"))))
dataDIntDt1999.df$ID = as.numeric(as.factor(with(dataDIntDt1999.df, paste(lon, lat,  sep="_"))))
dataDIntDt2000.df$ID = as.numeric(as.factor(with(dataDIntDt2000.df, paste(lon, lat,  sep="_"))))
dataDIntDt2001.df$ID = as.numeric(as.factor(with(dataDIntDt2001.df, paste(lon, lat,  sep="_"))))
dataDIntDt2002.df$ID = as.numeric(as.factor(with(dataDIntDt2002.df, paste(lon, lat,  sep="_"))))
dataDIntDt2003.df$ID = as.numeric(as.factor(with(dataDIntDt2003.df, paste(lon, lat,  sep="_"))))
dataDIntDt2004.df$ID = as.numeric(as.factor(with(dataDIntDt2004.df, paste(lon, lat,  sep="_"))))
dataDIntDt2005.df$ID = as.numeric(as.factor(with(dataDIntDt2005.df, paste(lon, lat,  sep="_"))))
dataDIntDt2006.df$ID = as.numeric(as.factor(with(dataDIntDt2006.df, paste(lon, lat,  sep="_"))))
dataDIntDt2007.df$ID = as.numeric(as.factor(with(dataDIntDt2007.df, paste(lon, lat,  sep="_"))))
dataDIntDt2008.df$ID = as.numeric(as.factor(with(dataDIntDt2008.df, paste(lon, lat,  sep="_"))))
dataDIntDt2009.df$ID = as.numeric(as.factor(with(dataDIntDt2009.df, paste(lon, lat,  sep="_"))))
dataDIntDt2010.df$ID = as.numeric(as.factor(with(dataDIntDt2010.df, paste(lon, lat,  sep="_"))))
dataDIntDt2011.df$ID = as.numeric(as.factor(with(dataDIntDt2011.df, paste(lon, lat,  sep="_"))))
dataDIntDt2012.df$ID = as.numeric(as.factor(with(dataDIntDt2012.df, paste(lon, lat,  sep="_"))))
dataDIntDt2013.df$ID = as.numeric(as.factor(with(dataDIntDt2013.df, paste(lon, lat,  sep="_"))))
dataDIntDt2014.df$ID = as.numeric(as.factor(with(dataDIntDt2014.df, paste(lon, lat,  sep="_"))))

Intensification = rbind(dataDIntDt1975.df,dataDIntDt1976.df, dataDIntDt1977.df, dataDIntDt1978.df, dataDIntDt1979.df,
                        dataDIntDt1980.df, dataDIntDt1981.df, dataDIntDt1982.df, dataDIntDt1983.df,
                        dataDIntDt1984.df, dataDIntDt1985.df, dataDIntDt1986.df, dataDIntDt1987.df,
                        dataDIntDt1988.df, dataDIntDt1989.df, dataDIntDt1990.df, dataDIntDt1991.df, 
                        dataDIntDt1992.df, dataDIntDt1993.df, dataDIntDt1994.df, dataDIntDt1995.df, 
                        dataDIntDt1996.df, dataDIntDt1997.df, dataDIntDt1998.df, dataDIntDt1999.df,
                        dataDIntDt2000.df, dataDIntDt2001.df, dataDIntDt2002.df, dataDIntDt2003.df,
                        dataDIntDt2004.df, dataDIntDt2005.df, dataDIntDt2006.df, dataDIntDt2007.df,
                        dataDIntDt2008.df, dataDIntDt2009.df, dataDIntDt2010.df, dataDIntDt2011.df,
                        dataDIntDt2012.df, dataDIntDt2013.df, dataDIntDt2014.df) 

Intensification$ID = as.integer(Intensification$ID)

looper = nrow(Intensification)

while(looper > 0)
{
  if ((Intensification$ID[looper] == 50) == TRUE | (Intensification$ID[looper] == 46) == TRUE |
      (Intensification$ID[looper] == 45) == TRUE | (Intensification$ID[looper] == 35) == TRUE |
      (Intensification$ID[looper] == 49) == TRUE | (Intensification$ID[looper] == 40) == TRUE|
      (Intensification$ID[looper] == 44) == TRUE | (Intensification$ID[looper] == 3) == TRUE |
      (Intensification$ID[looper] == 4) == TRUE)
  {
    Intensification = Intensification[-looper,]
  }
  looper = looper - 1
}

datasst1975.df = as.data.frame(data1975.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1975.df) <- c("lon", "lat", "sst")
datasst1976.df = as.data.frame(data1976.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1976.df) <- c("lon", "lat", "sst")
datasst1977.df = as.data.frame(data1977.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1977.df) <- c("lon", "lat", "sst")
datasst1978.df = as.data.frame(data1978.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1978.df) <- c("lon", "lat", "sst")
datasst1979.df = as.data.frame(data1979.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1979.df) <- c("lon", "lat", "sst")
datasst1980.df = as.data.frame(data1980.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1980.df) <- c("lon", "lat", "sst")
datasst1981.df = as.data.frame(data1981.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1981.df) <- c("lon", "lat", "sst")
datasst1982.df = as.data.frame(data1982.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1982.df) <- c("lon", "lat", "sst")
datasst1983.df = as.data.frame(data1983.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1983.df) <- c("lon", "lat", "sst")
datasst1984.df = as.data.frame(data1984.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1984.df) <- c("lon", "lat", "sst")
datasst1985.df = as.data.frame(data1985.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1985.df) <- c("lon", "lat", "sst")
datasst1986.df = as.data.frame(data1986.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1986.df) <- c("lon", "lat", "sst")
datasst1987.df = as.data.frame(data1987.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1987.df) <- c("lon", "lat", "sst")
datasst1988.df = as.data.frame(data1988.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1988.df) <- c("lon", "lat", "sst")
datasst1989.df = as.data.frame(data1989.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1989.df) <- c("lon", "lat", "sst")
datasst1990.df = as.data.frame(data1990.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1990.df) <- c("lon", "lat", "sst")
datasst1991.df = as.data.frame(data1991.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1991.df) <- c("lon", "lat", "sst")
datasst1992.df = as.data.frame(data1992.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1992.df) <- c("lon", "lat", "sst")
datasst1993.df = as.data.frame(data1993.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1993.df) <- c("lon", "lat", "sst")
datasst1994.df = as.data.frame(data1994.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1994.df) <- c("lon", "lat", "sst")
datasst1995.df = as.data.frame(data1995.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1995.df) <- c("lon", "lat", "sst")
datasst1996.df = as.data.frame(data1996.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1996.df) <- c("lon", "lat", "sst")
datasst1997.df = as.data.frame(data1997.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1997.df) <- c("lon", "lat", "sst")
datasst1998.df = as.data.frame(data1998.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1998.df) <- c("lon", "lat", "sst")
datasst1999.df = as.data.frame(data1999.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst1999.df) <- c("lon", "lat", "sst")
datasst2000.df = as.data.frame(data2000.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2000.df) <- c("lon", "lat", "sst")
datasst2001.df = as.data.frame(data2001.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2001.df) <- c("lon", "lat", "sst")
datasst2002.df = as.data.frame(data2002.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2002.df) <- c("lon", "lat", "sst")
datasst2003.df = as.data.frame(data2003.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2003.df) <- c("lon", "lat", "sst")
datasst2004.df = as.data.frame(data2004.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2004.df) <- c("lon", "lat", "sst")
datasst2005.df = as.data.frame(data2005.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2005.df) <- c("lon", "lat", "sst")
datasst2006.df = as.data.frame(data2006.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2006.df) <- c("lon", "lat", "sst")
datasst2007.df = as.data.frame(data2007.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2007.df) <- c("lon", "lat", "sst")
datasst2008.df = as.data.frame(data2008.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2008.df) <- c("lon", "lat", "sst")
datasst2009.df = as.data.frame(data2009.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2009.df) <- c("lon", "lat", "sst")
datasst2010.df = as.data.frame(data2010.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2010.df) <- c("lon", "lat", "sst")
datasst2011.df = as.data.frame(data2011.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2011.df) <- c("lon", "lat", "sst")
datasst2012.df = as.data.frame(data2012.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2012.df) <- c("lon", "lat", "sst")
datasst2013.df = as.data.frame(data2013.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2013.df) <- c("lon", "lat", "sst")
datasst2014.df = as.data.frame(data2014.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(datasst2014.df) <- c("lon", "lat", "sst")

datasst1975.df$Year[1:50] = 1975
datasst1976.df$Year[1:50] = 1976
datasst1977.df$Year[1:50] = 1977
datasst1978.df$Year[1:50] = 1978
datasst1979.df$Year[1:50] = 1979
datasst1980.df$Year[1:50] = 1980
datasst1981.df$Year[1:50] = 1981
datasst1982.df$Year[1:50] = 1982
datasst1983.df$Year[1:50] = 1983
datasst1984.df$Year[1:50] = 1984
datasst1985.df$Year[1:50] = 1985
datasst1986.df$Year[1:50] = 1986
datasst1987.df$Year[1:50] = 1987
datasst1988.df$Year[1:50] = 1988
datasst1989.df$Year[1:50] = 1989
datasst1990.df$Year[1:50] = 1990
datasst1991.df$Year[1:50] = 1991
datasst1992.df$Year[1:50] = 1992
datasst1993.df$Year[1:50] = 1993
datasst1994.df$Year[1:50] = 1994
datasst1995.df$Year[1:50] = 1995
datasst1996.df$Year[1:50] = 1996
datasst1997.df$Year[1:50] = 1997
datasst1998.df$Year[1:50] = 1998
datasst1999.df$Year[1:50] = 1999
datasst2000.df$Year[1:50] = 2000
datasst2001.df$Year[1:50] = 2001
datasst2002.df$Year[1:50] = 2002
datasst2003.df$Year[1:50] = 2003
datasst2004.df$Year[1:50] = 2004
datasst2005.df$Year[1:50] = 2005
datasst2006.df$Year[1:50] = 2006
datasst2007.df$Year[1:50] = 2007
datasst2008.df$Year[1:50] = 2008
datasst2009.df$Year[1:50] = 2009
datasst2010.df$Year[1:50] = 2010
datasst2011.df$Year[1:50] = 2011
datasst2012.df$Year[1:50] = 2012
datasst2013.df$Year[1:50] = 2013
datasst2014.df$Year[1:50] = 2014

datasst1975.df$ID = as.numeric(as.factor(with(datasst1975.df, paste(lon, lat,  sep="_"))))
datasst1976.df$ID = as.numeric(as.factor(with(datasst1976.df, paste(lon, lat,  sep="_"))))
datasst1977.df$ID = as.numeric(as.factor(with(datasst1977.df, paste(lon, lat,  sep="_"))))
datasst1978.df$ID = as.numeric(as.factor(with(datasst1978.df, paste(lon, lat,  sep="_"))))
datasst1979.df$ID = as.numeric(as.factor(with(datasst1979.df, paste(lon, lat,  sep="_"))))
datasst1980.df$ID = as.numeric(as.factor(with(datasst1980.df, paste(lon, lat,  sep="_"))))
datasst1981.df$ID = as.numeric(as.factor(with(datasst1981.df, paste(lon, lat,  sep="_"))))
datasst1982.df$ID = as.numeric(as.factor(with(datasst1982.df, paste(lon, lat,  sep="_"))))
datasst1983.df$ID = as.numeric(as.factor(with(datasst1983.df, paste(lon, lat,  sep="_"))))
datasst1984.df$ID = as.numeric(as.factor(with(datasst1984.df, paste(lon, lat,  sep="_"))))
datasst1985.df$ID = as.numeric(as.factor(with(datasst1985.df, paste(lon, lat,  sep="_"))))
datasst1986.df$ID = as.numeric(as.factor(with(datasst1986.df, paste(lon, lat,  sep="_"))))
datasst1987.df$ID = as.numeric(as.factor(with(datasst1987.df, paste(lon, lat,  sep="_"))))
datasst1988.df$ID = as.numeric(as.factor(with(datasst1988.df, paste(lon, lat,  sep="_"))))
datasst1989.df$ID = as.numeric(as.factor(with(datasst1989.df, paste(lon, lat,  sep="_"))))
datasst1990.df$ID = as.numeric(as.factor(with(datasst1990.df, paste(lon, lat,  sep="_"))))
datasst1991.df$ID = as.numeric(as.factor(with(datasst1991.df, paste(lon, lat,  sep="_"))))
datasst1992.df$ID = as.numeric(as.factor(with(datasst1992.df, paste(lon, lat,  sep="_"))))
datasst1993.df$ID = as.numeric(as.factor(with(datasst1993.df, paste(lon, lat,  sep="_"))))
datasst1994.df$ID = as.numeric(as.factor(with(datasst1994.df, paste(lon, lat,  sep="_"))))
datasst1995.df$ID = as.numeric(as.factor(with(datasst1995.df, paste(lon, lat,  sep="_"))))
datasst1996.df$ID = as.numeric(as.factor(with(datasst1996.df, paste(lon, lat,  sep="_"))))
datasst1997.df$ID = as.numeric(as.factor(with(datasst1997.df, paste(lon, lat,  sep="_"))))
datasst1998.df$ID = as.numeric(as.factor(with(datasst1998.df, paste(lon, lat,  sep="_"))))
datasst1999.df$ID = as.numeric(as.factor(with(datasst1999.df, paste(lon, lat,  sep="_"))))
datasst2000.df$ID = as.numeric(as.factor(with(datasst2000.df, paste(lon, lat,  sep="_"))))
datasst2001.df$ID = as.numeric(as.factor(with(datasst2001.df, paste(lon, lat,  sep="_"))))
datasst2002.df$ID = as.numeric(as.factor(with(datasst2002.df, paste(lon, lat,  sep="_"))))
datasst2003.df$ID = as.numeric(as.factor(with(datasst2003.df, paste(lon, lat,  sep="_"))))
datasst2004.df$ID = as.numeric(as.factor(with(datasst2004.df, paste(lon, lat,  sep="_"))))
datasst2005.df$ID = as.numeric(as.factor(with(datasst2005.df, paste(lon, lat,  sep="_"))))
datasst2006.df$ID = as.numeric(as.factor(with(datasst2006.df, paste(lon, lat,  sep="_"))))
datasst2007.df$ID = as.numeric(as.factor(with(datasst2007.df, paste(lon, lat,  sep="_"))))
datasst2008.df$ID = as.numeric(as.factor(with(datasst2008.df, paste(lon, lat,  sep="_"))))
datasst2009.df$ID = as.numeric(as.factor(with(datasst2009.df, paste(lon, lat,  sep="_"))))
datasst2010.df$ID = as.numeric(as.factor(with(datasst2010.df, paste(lon, lat,  sep="_"))))
datasst2011.df$ID = as.numeric(as.factor(with(datasst2011.df, paste(lon, lat,  sep="_"))))
datasst2012.df$ID = as.numeric(as.factor(with(datasst2012.df, paste(lon, lat,  sep="_"))))
datasst2013.df$ID = as.numeric(as.factor(with(datasst2013.df, paste(lon, lat,  sep="_"))))
datasst2014.df$ID = as.numeric(as.factor(with(datasst2014.df, paste(lon, lat,  sep="_"))))

dataInt1975.df = as.data.frame(data1975.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1975.df) <- c("lon", "lat", "Int")
dataInt1976.df = as.data.frame(data1976.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1976.df) <- c("lon", "lat", "Int")
dataInt1977.df = as.data.frame(data1977.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1977.df) <- c("lon", "lat", "Int")
dataInt1978.df = as.data.frame(data1978.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1978.df) <- c("lon", "lat", "Int")
dataInt1979.df = as.data.frame(data1979.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1979.df) <- c("lon", "lat", "Int")
dataInt1980.df = as.data.frame(data1980.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1980.df) <- c("lon", "lat", "Int")
dataInt1981.df = as.data.frame(data1981.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1981.df) <- c("lon", "lat", "Int")
dataInt1982.df = as.data.frame(data1982.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1982.df) <- c("lon", "lat", "Int")
dataInt1983.df = as.data.frame(data1983.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1983.df) <- c("lon", "lat", "Int")
dataInt1984.df = as.data.frame(data1984.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1984.df) <- c("lon", "lat", "Int")
dataInt1985.df = as.data.frame(data1985.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1985.df) <- c("lon", "lat", "Int")
dataInt1986.df = as.data.frame(data1986.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1986.df) <- c("lon", "lat", "Int")
dataInt1987.df = as.data.frame(data1987.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1987.df) <- c("lon", "lat", "Int")
dataInt1988.df = as.data.frame(data1988.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1988.df) <- c("lon", "lat", "Int")
dataInt1989.df = as.data.frame(data1989.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1989.df) <- c("lon", "lat", "Int")
dataInt1990.df = as.data.frame(data1990.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1990.df) <- c("lon", "lat", "Int")
dataInt1991.df = as.data.frame(data1991.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1991.df) <- c("lon", "lat", "Int")
dataInt1992.df = as.data.frame(data1992.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1992.df) <- c("lon", "lat", "Int")
dataInt1993.df = as.data.frame(data1993.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1993.df) <- c("lon", "lat", "Int")
dataInt1994.df = as.data.frame(data1994.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1994.df) <- c("lon", "lat", "Int")
dataInt1995.df = as.data.frame(data1995.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1995.df) <- c("lon", "lat", "Int")
dataInt1996.df = as.data.frame(data1996.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1996.df) <- c("lon", "lat", "Int")
dataInt1997.df = as.data.frame(data1997.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1997.df) <- c("lon", "lat", "Int")
dataInt1998.df = as.data.frame(data1998.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1998.df) <- c("lon", "lat", "Int")
dataInt1999.df = as.data.frame(data1999.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt1999.df) <- c("lon", "lat", "Int")
dataInt2000.df = as.data.frame(data2000.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2000.df) <- c("lon", "lat", "Int")
dataInt2001.df = as.data.frame(data2001.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2001.df) <- c("lon", "lat", "Int")
dataInt2002.df = as.data.frame(data2002.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2002.df) <- c("lon", "lat", "Int")
dataInt2003.df = as.data.frame(data2003.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2003.df) <- c("lon", "lat", "Int")
dataInt2004.df = as.data.frame(data2004.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2004.df) <- c("lon", "lat", "Int")
dataInt2005.df = as.data.frame(data2005.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2005.df) <- c("lon", "lat", "Int")
dataInt2006.df = as.data.frame(data2006.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2006.df) <- c("lon", "lat", "Int")
dataInt2007.df = as.data.frame(data2007.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2007.df) <- c("lon", "lat", "Int")
dataInt2008.df = as.data.frame(data2008.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2008.df) <- c("lon", "lat", "Int")
dataInt2009.df = as.data.frame(data2009.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2009.df) <- c("lon", "lat", "Int")
dataInt2010.df = as.data.frame(data2010.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2010.df) <- c("lon", "lat", "Int")
dataInt2011.df = as.data.frame(data2011.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2011.df) <- c("lon", "lat", "Int")
dataInt2012.df = as.data.frame(data2012.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2012.df) <- c("lon", "lat", "Int")
dataInt2013.df = as.data.frame(data2013.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2013.df) <- c("lon", "lat", "Int")
dataInt2014.df = as.data.frame(data2014.grid, row.names=NULL, optional = TRUE, xy = TRUE, centroids = TRUE)
colnames(dataInt2014.df) <- c("lon", "lat", "Int")

dataInt1975.df$Year[1:50] = 1975
dataInt1976.df$Year[1:50] = 1976
dataInt1977.df$Year[1:50] = 1977
dataInt1978.df$Year[1:50] = 1978
dataInt1979.df$Year[1:50] = 1979
dataInt1980.df$Year[1:50] = 1980
dataInt1981.df$Year[1:50] = 1981
dataInt1982.df$Year[1:50] = 1982
dataInt1983.df$Year[1:50] = 1983
dataInt1984.df$Year[1:50] = 1984
dataInt1985.df$Year[1:50] = 1985
dataInt1986.df$Year[1:50] = 1986
dataInt1987.df$Year[1:50] = 1987
dataInt1988.df$Year[1:50] = 1988
dataInt1989.df$Year[1:50] = 1989
dataInt1990.df$Year[1:50] = 1990
dataInt1991.df$Year[1:50] = 1991
dataInt1992.df$Year[1:50] = 1992
dataInt1993.df$Year[1:50] = 1993
dataInt1994.df$Year[1:50] = 1994
dataInt1995.df$Year[1:50] = 1995
dataInt1996.df$Year[1:50] = 1996
dataInt1997.df$Year[1:50] = 1997
dataInt1998.df$Year[1:50] = 1998
dataInt1999.df$Year[1:50] = 1999
dataInt2000.df$Year[1:50] = 2000
dataInt2001.df$Year[1:50] = 2001
dataInt2002.df$Year[1:50] = 2002
dataInt2003.df$Year[1:50] = 2003
dataInt2004.df$Year[1:50] = 2004
dataInt2005.df$Year[1:50] = 2005
dataInt2006.df$Year[1:50] = 2006
dataInt2007.df$Year[1:50] = 2007
dataInt2008.df$Year[1:50] = 2008
dataInt2009.df$Year[1:50] = 2009
dataInt2010.df$Year[1:50] = 2010
dataInt2011.df$Year[1:50] = 2011
dataInt2012.df$Year[1:50] = 2012
dataInt2013.df$Year[1:50] = 2013
dataInt2014.df$Year[1:50] = 2014

dataInt1975.df$ID = as.numeric(as.factor(with(dataInt1975.df, paste(lon, lat,  sep="_"))))
dataInt1976.df$ID = as.numeric(as.factor(with(dataInt1976.df, paste(lon, lat,  sep="_"))))
dataInt1977.df$ID = as.numeric(as.factor(with(dataInt1977.df, paste(lon, lat,  sep="_"))))
dataInt1978.df$ID = as.numeric(as.factor(with(dataInt1978.df, paste(lon, lat,  sep="_"))))
dataInt1979.df$ID = as.numeric(as.factor(with(dataInt1979.df, paste(lon, lat,  sep="_"))))
dataInt1980.df$ID = as.numeric(as.factor(with(dataInt1980.df, paste(lon, lat,  sep="_"))))
dataInt1981.df$ID = as.numeric(as.factor(with(dataInt1981.df, paste(lon, lat,  sep="_"))))
dataInt1982.df$ID = as.numeric(as.factor(with(dataInt1982.df, paste(lon, lat,  sep="_"))))
dataInt1983.df$ID = as.numeric(as.factor(with(dataInt1983.df, paste(lon, lat,  sep="_"))))
dataInt1984.df$ID = as.numeric(as.factor(with(dataInt1984.df, paste(lon, lat,  sep="_"))))
dataInt1985.df$ID = as.numeric(as.factor(with(dataInt1985.df, paste(lon, lat,  sep="_"))))
dataInt1986.df$ID = as.numeric(as.factor(with(dataInt1986.df, paste(lon, lat,  sep="_"))))
dataInt1987.df$ID = as.numeric(as.factor(with(dataInt1987.df, paste(lon, lat,  sep="_"))))
dataInt1988.df$ID = as.numeric(as.factor(with(dataInt1988.df, paste(lon, lat,  sep="_"))))
dataInt1989.df$ID = as.numeric(as.factor(with(dataInt1989.df, paste(lon, lat,  sep="_"))))
dataInt1990.df$ID = as.numeric(as.factor(with(dataInt1990.df, paste(lon, lat,  sep="_"))))
dataInt1991.df$ID = as.numeric(as.factor(with(dataInt1991.df, paste(lon, lat,  sep="_"))))
dataInt1992.df$ID = as.numeric(as.factor(with(dataInt1992.df, paste(lon, lat,  sep="_"))))
dataInt1993.df$ID = as.numeric(as.factor(with(dataInt1993.df, paste(lon, lat,  sep="_"))))
dataInt1994.df$ID = as.numeric(as.factor(with(dataInt1994.df, paste(lon, lat,  sep="_"))))
dataInt1995.df$ID = as.numeric(as.factor(with(dataInt1995.df, paste(lon, lat,  sep="_"))))
dataInt1996.df$ID = as.numeric(as.factor(with(dataInt1996.df, paste(lon, lat,  sep="_"))))
dataInt1997.df$ID = as.numeric(as.factor(with(dataInt1997.df, paste(lon, lat,  sep="_"))))
dataInt1998.df$ID = as.numeric(as.factor(with(dataInt1998.df, paste(lon, lat,  sep="_"))))
dataInt1999.df$ID = as.numeric(as.factor(with(dataInt1999.df, paste(lon, lat,  sep="_"))))
dataInt2000.df$ID = as.numeric(as.factor(with(dataInt2000.df, paste(lon, lat,  sep="_"))))
dataInt2001.df$ID = as.numeric(as.factor(with(dataInt2001.df, paste(lon, lat,  sep="_"))))
dataInt2002.df$ID = as.numeric(as.factor(with(dataInt2002.df, paste(lon, lat,  sep="_"))))
dataInt2003.df$ID = as.numeric(as.factor(with(dataInt2003.df, paste(lon, lat,  sep="_"))))
dataInt2004.df$ID = as.numeric(as.factor(with(dataInt2004.df, paste(lon, lat,  sep="_"))))
dataInt2005.df$ID = as.numeric(as.factor(with(dataInt2005.df, paste(lon, lat,  sep="_"))))
dataInt2006.df$ID = as.numeric(as.factor(with(dataInt2006.df, paste(lon, lat,  sep="_"))))
dataInt2007.df$ID = as.numeric(as.factor(with(dataInt2007.df, paste(lon, lat,  sep="_"))))
dataInt2008.df$ID = as.numeric(as.factor(with(dataInt2008.df, paste(lon, lat,  sep="_"))))
dataInt2009.df$ID = as.numeric(as.factor(with(dataInt2009.df, paste(lon, lat,  sep="_"))))
dataInt2010.df$ID = as.numeric(as.factor(with(dataInt2010.df, paste(lon, lat,  sep="_"))))
dataInt2011.df$ID = as.numeric(as.factor(with(dataInt2011.df, paste(lon, lat,  sep="_"))))
dataInt2012.df$ID = as.numeric(as.factor(with(dataInt2012.df, paste(lon, lat,  sep="_"))))
dataInt2013.df$ID = as.numeric(as.factor(with(dataInt2013.df, paste(lon, lat,  sep="_"))))
dataInt2014.df$ID = as.numeric(as.factor(with(dataInt2014.df, paste(lon, lat,  sep="_"))))

Intensity = rbind(dataInt1975.df,dataInt1976.df, dataInt1977.df, dataInt1978.df, dataInt1979.df,
                  dataInt1980.df, dataInt1981.df, dataInt1982.df, dataInt1983.df,
                  dataInt1984.df, dataInt1985.df, dataInt1986.df, dataInt1987.df,
                  dataInt1988.df, dataInt1989.df, dataInt1990.df, dataInt1991.df, 
                  dataInt1992.df, dataInt1993.df, dataInt1994.df, dataInt1995.df, 
                  dataInt1996.df, dataInt1997.df, dataInt1998.df, dataInt1999.df,
                  dataInt2000.df, dataInt2001.df, dataInt2002.df, dataInt2003.df,
                  dataInt2004.df, dataInt2005.df, dataInt2006.df, dataInt2007.df,
                  dataInt2008.df, dataInt2009.df, dataInt2010.df, dataInt2011.df,
                  dataInt2012.df, dataInt2013.df, dataInt2014.df) 

Intensity$ID = as.integer(Intensity$ID)

looper = nrow(Intensity)

while(looper > 0)
{
  if ((Intensity$ID[looper] == 50) == TRUE | (Intensity$ID[looper] == 46) == TRUE |
      (Intensity$ID[looper] == 45) == TRUE | (Intensity$ID[looper] == 35) == TRUE |
      (Intensity$ID[looper] == 49) == TRUE | (Intensity$ID[looper] == 40) == TRUE|
      (Intensity$ID[looper] == 44) == TRUE | (Intensity$ID[looper] == 3) == TRUE |
      (Intensity$ID[looper] == 4) == TRUE)
  {
    Intensity = Intensity[-looper,]
  }
  looper = looper - 1
}

SSTdata = rbind(datasst1975.df,datasst1976.df, datasst1977.df, datasst1978.df, datasst1979.df,
                datasst1980.df, datasst1981.df, datasst1982.df, datasst1983.df,
                datasst1984.df, datasst1985.df, datasst1986.df, datasst1987.df,
                datasst1988.df, datasst1989.df, datasst1990.df, datasst1991.df, 
                datasst1992.df, datasst1993.df, datasst1994.df, datasst1995.df, 
                datasst1996.df, datasst1997.df, datasst1998.df, datasst1999.df,
                datasst2000.df, datasst2001.df, datasst2002.df, datasst2003.df,
                datasst2004.df, datasst2005.df, datasst2006.df, datasst2007.df,
                datasst2008.df, datasst2009.df, datasst2010.df, datasst2011.df,
                datasst2012.df, datasst2013.df, datasst2014.df) 

SSTdata$ID = as.integer(SSTdata$ID)

looper = nrow(SSTdata)

while(looper > 0)
{
  if ((SSTdata$ID[looper] == 50) == TRUE | (SSTdata$ID[looper] == 46) == TRUE |
      (SSTdata$ID[looper] == 45) == TRUE | (SSTdata$ID[looper] == 35) == TRUE |
      (SSTdata$ID[looper] == 49) == TRUE | (SSTdata$ID[looper] == 40) == TRUE|
      (SSTdata$ID[looper] == 44) == TRUE | (SSTdata$ID[looper] == 3) == TRUE |
      (SSTdata$ID[looper] == 4) == TRUE)
  {
    SSTdata = SSTdata[-looper,]
  }
  looper = looper - 1
}

ID = datasst1975.df$ID

sstData.df = data.frame(ID)

sstData.df = cbind(sstData.df, datasst1975.df$sst)
sstData.df = cbind(sstData.df, datasst1976.df$sst)
sstData.df = cbind(sstData.df, datasst1977.df$sst)
sstData.df = cbind(sstData.df, datasst1978.df$sst)
sstData.df = cbind(sstData.df, datasst1979.df$sst)
sstData.df = cbind(sstData.df, datasst1980.df$sst)
sstData.df = cbind(sstData.df, datasst1981.df$sst)
sstData.df = cbind(sstData.df, datasst1982.df$sst)
sstData.df = cbind(sstData.df, datasst1983.df$sst)
sstData.df = cbind(sstData.df, datasst1984.df$sst)
sstData.df = cbind(sstData.df, datasst1985.df$sst)
sstData.df = cbind(sstData.df, datasst1986.df$sst)
sstData.df = cbind(sstData.df, datasst1987.df$sst)
sstData.df = cbind(sstData.df, datasst1988.df$sst)
sstData.df = cbind(sstData.df, datasst1989.df$sst)
sstData.df = cbind(sstData.df, datasst1990.df$sst)
sstData.df = cbind(sstData.df, datasst1991.df$sst)
sstData.df = cbind(sstData.df, datasst1992.df$sst)
sstData.df = cbind(sstData.df, datasst1993.df$sst)
sstData.df = cbind(sstData.df, datasst1994.df$sst)
sstData.df = cbind(sstData.df, datasst1995.df$sst)
sstData.df = cbind(sstData.df, datasst1996.df$sst)
sstData.df = cbind(sstData.df, datasst1997.df$sst)
sstData.df = cbind(sstData.df, datasst1998.df$sst)
sstData.df = cbind(sstData.df, datasst1999.df$sst)
sstData.df = cbind(sstData.df, datasst2000.df$sst)
sstData.df = cbind(sstData.df, datasst2001.df$sst)
sstData.df = cbind(sstData.df, datasst2002.df$sst)
sstData.df = cbind(sstData.df, datasst2003.df$sst)
sstData.df = cbind(sstData.df, datasst2004.df$sst)
sstData.df = cbind(sstData.df, datasst2005.df$sst)
sstData.df = cbind(sstData.df, datasst2006.df$sst)
sstData.df = cbind(sstData.df, datasst2007.df$sst)
sstData.df = cbind(sstData.df, datasst2008.df$sst)
sstData.df = cbind(sstData.df, datasst2009.df$sst)
sstData.df = cbind(sstData.df, datasst2010.df$sst)
sstData.df = cbind(sstData.df, datasst2011.df$sst)
sstData.df = cbind(sstData.df, datasst2012.df$sst)
sstData.df = cbind(sstData.df, datasst2013.df$sst)
sstData.df = cbind(sstData.df, datasst2014.df$sst)

x = 1
while (x < 41){
  colnames(sstData.df)[x+1] = Yr[x]
  x = x+1
}

sstData.df$ID = as.integer(sstData.df$ID)

looper = nrow(sstData.df)

while(looper > 0)
{
  if ((sstData.df$ID[looper] == 50) == TRUE | (sstData.df$ID[looper] == 46) == TRUE |
      (sstData.df$ID[looper] == 45) == TRUE | (sstData.df$ID[looper] == 35) == TRUE |
      (sstData.df$ID[looper] == 49) == TRUE | (sstData.df$ID[looper] == 40) == TRUE|
      (sstData.df$ID[looper] == 44) == TRUE | (sstData.df$ID[looper] == 3) == TRUE |
      (sstData.df$ID[looper] == 4) == TRUE)
  {
    sstData.df = sstData.df[-looper,]
  }
  looper = looper - 1
}


data.df = merge(Intensification, Intensity)
data.df = merge(data.df, SSTdata)

load("mjoRMM.RData")

mjoRMM$rmmSum = mjoRMM$meanRMM1 + mjoRMM$meanRMM2

data.df["RMM1"] = NA
data.df["RMM2"] = NA

data.df  = data.df[with(data.df, order(Year)),]

Yr = 1975
counter = 1
loop = 1

while (Yr < 2014)
{
  while ((data.df$Year[counter] == Yr)== TRUE){  
    data.df$RMM1[counter] = mjoRMM$meanRMM1[loop]
    data.df$RMM2[counter] = mjoRMM$meanRMM2[loop]
    data.df$rmmSum[counter] = mjoRMM$rmmSum[loop]
    counter = counter + 1
  }
  Yr = Yr + 1
  loop = loop + 1
}

histDIntDt = ggplot(data.df, aes(DIntDt)) + geom_histogram(binwidth=0.2,
                                                           color = "white", fill = "#6A51A3") +
  xlab(expression(paste("Mean Intensification [m ", s^-1, " per h]"))) +
  ylab("Number of Grid Cells") 
histDIntDt = histDIntDt + ggtitle("a") + theme(plot.title = element_text(hjust = 0))
histDIntDt