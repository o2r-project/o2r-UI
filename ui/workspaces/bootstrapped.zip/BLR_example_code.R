#######################################################################
### Bootstrapped Loess regression for soil depth profile comparison ###
#######################################################################

  # Set working directory as required.

  # Read in file containing example data.
  dat1 = read.csv("LUC.soil.data.csv", header=TRUE, sep=",")
  str(dat1) 

############################################################
## EXAMPLE 1 - Fixed-depth profiles of soil C content (%) ##
############################################################

#######################################################
## Generate bootstrap samples and Loess predictions ###

  ## Create matrix to hold bootstrap predicted values; 1000 bootstraps. 
  mat1 = matrix(nrow=1000, ncol=10, byrow=TRUE)

  ## Function to derive bootstrapped data, fit Loess and store.
  for (i in 1:1000){
  
    nlength = length(dat1$depth.number)
    boot_id = sample(nlength, length(dat1$landuse[dat1$landuse=="LU1"]))
    newdat = dat1[boot_id, ]
  
    lo1 = loess(formula = soil.C.per ~ depth.number, 
              data = newdat, na.rm=TRUE)
  
    mat1[i,] = predict(lo1, newdata=seq(1,10,by=1))
  
    }

  # end of function

  ## Derive confidence envelope (= null hypothesis of no difference).
  mat1_ci = apply(mat1, 2, quantile, probs=c(0.05, 0.95), na.rm=TRUE)

  ## Loess fit and predict for Land Use 2.
  lo2 = loess(formula = soil.C.per ~ depth.number, 
            data = dat1[dat1$landuse=="LU2",])

  mat2 = predict(lo2, newdata=seq(1,10,by=1))

####################################################
## Plotting of confidence envelope and Loess fit ###

  # Set up generic plotting settings
  yunit = paste("Depth")
  xunit = paste("Soil C content (%)")
  palette(c("grey86", "black"))

  # Plot data from function
  plot(dat1$depth.number ~ dat1$soil.C.per,
       col=dat1$landuse, pch=19,
       xlab=xunit, ylab=yunit,
       xlim=c(0,4), ylim=c(10,0))

  lines(mat1_ci[1,], 1:10, lty="dashed", lwd=1.8)
  lines(mat1_ci[2,], 1:10, lty="dashed", lwd=1.8)
  lines(mat2, 1:10, type="l", lwd=2)

##############################################################
## Compute overall P value for difference between profiles ###

  # Compute mean and standard deviation across the simulations at each depth.
  dpth_var = apply(mat1, 2, var)
  dpth_sd = sqrt(mat1)
  dpth_mean = apply(mat1, 2, mean)

  # Use the derived statistics to build a test statistic.
  T_stat = function(x) sum( (x-dpth_mean)/dpth_sd)

  # Apply the test statistic to the bootstrap fits.
  Tsim=apply(mat1, 1, T_stat)

  # Apply the test statistic to the observed fit. 
  Tdata = T_stat(mat2)

  # Evaluate p value as proportion of simulations with test statistics more extreme than the observed test statistic. 
  Tpval = (sum(Tdata<Tsim)+1)/(1000+1)  


##########################################################################
## EXAMPLE 2 - Mass-based profiles of soil C stock (tonnes per hectare) ##
##########################################################################

#######################################################
## Generate bootstrap samples and Loess predictions ###

  ## Calculate range limit to pass to predictions.
  max.C = round(max(dat1$soil.C.stock, na.rm=TRUE))
  max.mass = round(max(dat1$soil.mass, na.rm=TRUE))

  ## Create matrix to hold bootstrap predicted values; 1000 bootstraps.
  mat1 = matrix(nrow=1000, ncol=max.mass, byrow=TRUE)

  ## Function to derive bootstrapped data, fit Loess and store.
  for (i in 1:1000){
  
    nlength = length(dat1$soil.mass)
    boot_id = sample(nlength, length(dat1$landuse[dat1$landuse=="LU1"]))
    newdat = dat1[boot_id, ]
  
    lo1 = loess(formula = soil.C.stock ~ soil.mass, 
              data = newdat, na.rm=TRUE)
    
    mat1[i,] = predict(lo1, newdata=seq(1,max.mass,by=1))
  
    }

  # end of function

  ## Derive confidence envelope (= null hypothesis of no difference).
  mat1_ci = apply(mat1, 2, quantile, probs=c(0.05, 0.95), na.rm=TRUE)

  ## Loess fit and predict for Land Use 2.
  lo2 = loess(formula = soil.C.stock ~ soil.mass, 
            data = dat1[dat1$landuse=="LU2", ])

  mat2 = predict(lo2, newdata=seq(1, max.mass, by=1))

####################################################
## Plotting of confidence envelope and Loess fit ###

  # Set up generic plotting settings
  yunit = expression(paste("Soil C " , "(" ,"t ha"^-1, ")" ))
  xunit = expression(paste("Soil mass " , "(" ,"t ha"^-1, ")" ))
  palette(c("grey86", "black"))

  # Plot data from function
  plot(dat1$soil.mass ~ dat1$soil.C.stock,
       col=dat1$landuse, pch=19,
       xlab=yunit, ylab=xunit,
       xlim=c(0,120), ylim=c(18000,0))

  lines(mat1_ci[1,], 1:max.mass, lty="dashed", lwd=1.8)
  lines(mat1_ci[2,], 1:max.mass, lty="dashed", lwd=1.8)
  lines(mat2, 1:max.mass, type="l", lwd=2)

##############################################################
## Compute overall P value for difference between profiles ###

	# Compute mean and standard deviation across the simulations at each depth.
  dpth_var = apply(mat1, 2, var)
  dpth_sd = sqrt(mat1)
  dpth_mean = apply(mat1, 2, mean)

  # Use the derived statistics to build a test statistic.
  T_stat = function(x) sum( (x-dpth_mean)/dpth_sd)
  
  # Apply the test statistic to the bootstrap fits.
  Tsim=apply(mat1, 1, T_stat)
  
  # Apply the test statistic to the observed fit. 
  Tdata = T_stat(mat2)
  
  ## Evaluate p value as proportion of simulations with test statistics more extreme than the observed test statistic. 
  Tpval = (sum(Tdata<Tsim)+1)/(1000+1)    
 