#' @get /figure2
#' @png 
function(newValue){ 
  newValue = as.numeric(newValue) 
  dat1 = read.csv("LUC.soil.data.csv", header=TRUE, sep=",")
  
  ## Create matrix to hold bootstrap predicted values; 1000 bootstraps. 
  mat1 = matrix(nrow=1000, ncol=10, byrow=TRUE)
  
  ## Function to derive bootstrapped data, fit Loess and store.
  for (i in 1:1000){
    
    nlength = length(dat1$depth.number)
    boot_id = sample(nlength, length(dat1$landuse[dat1$landuse=="LU1"]))
    newdat = dat1[boot_id, ]
    
    lo1 = loess(formula = soil.C.per ~ depth.number, 
                data = newdat, na.rm=TRUE)
    
    mat1[i,] = predict(lo1, newdata=seq(1,10,by=1))
    
  }
  
  # end of function
  confIntervalRight = newValue
  ## Derive confidence envelope (= null hypothesis of no difference).
  mat1_ci = apply(mat1, 2, quantile, probs=c(0.05, confIntervalRight), na.rm=TRUE)
  
  ## Loess fit and predict for Land Use 2.
  lo2 = loess(formula = soil.C.per ~ depth.number, 
              data = dat1[dat1$landuse=="LU2",])
  
  mat2 = predict(lo2, newdata=seq(1,10,by=1))
  
  # Set up generic plotting settings
  yunit = paste("Depth")
  xunit = paste("Soil C content (%)")
  palette(c("grey86", "black"))
  
  # Plot data from function
  plot(dat1$depth.number ~ dat1$soil.C.per,
       col=dat1$landuse, pch=19,
       xlab=xunit, ylab=yunit,
       xlim=c(0,4), ylim=c(10,0))
  
  lines(mat1_ci[1,], 1:10, lty="dashed", lwd=1.8)
  lines(mat1_ci[2,], 1:10, lty="dashed", lwd=1.8)
  lines(mat2, 1:10, type="l", lwd=2)
}