library("plumber")
setwd(file.path("tmp", "o2r", "compendium", "ru0Sz"))
path = paste("figure3.R", sep = "")
r <- plumb(path)
r$run(host = "0.0.0.0", port=8123)
  