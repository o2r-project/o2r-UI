#' @get /figure4
#' @png 
function(newValue){ 
  startAnalysis <- Sys.time() 
  newValue = as.numeric(newValue) 
  library("stringr")
  library("plyr")
  library("ggplot2")
  library("MASS")
  deaths <- readRDS("deaths.rds")
  codes <- read.csv("icd-main.csv")
  codes$disease <- sapply(codes$disease, function(x) str_c(strwrap(x, width = 30), 
                                                           collapse = "\n"))
  names(codes)[1] <- "cod"
  codes <- codes[!duplicated(codes$cod), ]
  hod2 <- count(deaths, c("cod", "hod"))
  hod2 <- subset(hod2, !is.na(hod))
  hod2 <- join(hod2, codes)
  hod2 <- ddply(hod2, "cod", transform, prop = freq/sum(freq))
  
  # Compare to overall abundance
  overall <- ddply(hod2, "hod", summarise, freq_all = sum(freq))
  overall <- mutate(overall, prop_all = freq_all/sum(freq_all))
  
  hod2 <- join(overall, hod2, by = "hod")
  devi <- ddply(hod2, "cod", summarise, n = sum(freq), dist = mean((prop - prop_all)^2))
  filter = 50
  devi <- subset(devi, n > filter)
  devi$resid <- resid(rlm(log(dist) ~ log(n), data = devi))
  unusual <- subset(devi, resid > 1.5)
  constrain  = newValue
  hod_unusual_big <- match_df(hod2, subset(unusual, n > constrain))
  hod_unusual_sml <- match_df(hod2, subset(unusual, n <= constrain))
  plot(ggplot(hod_unusual_big, aes(hod, prop)) + geom_line(aes(y = prop_all), data = overall, 
                                                           colour = "grey50") + geom_line() + facet_wrap(~disease, ncol = 3))
  ggsave("unusual-big.pdf", width = 8, height = 6)
  last_plot() %+% hod_unusual_sml
  
  endAnalysis <- Sys.time() 
  totaltime <- difftime(endAnalysis, startAnalysis, units="secs") 
  message(paste("Total time is: ", totaltime)) 
}