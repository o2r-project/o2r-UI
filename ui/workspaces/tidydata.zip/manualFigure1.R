library("plyr")
library("ggplot2")
deaths <- readRDS("deaths.rds")
subset="hod"
hod_all <- subset(count(deaths, subset), !is.na(eval(parse(text=subset))))
plot(qplot(eval(parse(text=subset)), freq, data = hod_all, geom = "line") + scale_y_continuous("Number of deaths", 
                                                                     labels = function(x) format(x, big.mark = ",")) + xlab("Hour of day"))