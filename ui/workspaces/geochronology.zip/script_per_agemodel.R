Agemodel.stars("0309_CTY1", cc=3, smooth=0.3)
# Here you can included comments if you want. e.g. Smoothness at default 0.3

Agemodel.stars("0310_CTY2", cc=3, smooth=0.2) 
# Smoothness adjusted to 0.2 to improve fit.
