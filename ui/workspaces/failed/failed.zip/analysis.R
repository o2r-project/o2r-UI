data <- read.csv("data.csv")
data2 <- read.csv("data2.csv")
barplot(height = data$capacity, names.arg = data$year, ylab = "capacity", sub = "(c) Statista 2017")