########################################################################
# Creating a gas flaring emission dataset
# R Script 4/4 - write files for COSMO-ART
# Konrad Deetz
# 30 August, 2016
# linked to the publication of Deetz and Vogel (2016)
########################################################################

# Before you start this script you have to keep in mind that
# the file output structure is defined for the needs of the
# model COSMO-ART (Vogel et al., 2009). Maybe you have to
# change this according to the needs of your model. The output
# includes a <meta> file with meta information (flare position,
# volume stream, radiant heat and source temperature) and an
# <emission> file with the actual emissions (CO, SO2, NO, NO2).

# load libraries
#install.packages("fields")
library(fields)
library(maps)

# clean up
rm(list=ls())

# plot a quick look of CO?
plot.quicklook <- TRUE

# data directories
file.meta <- "../Step_2_calc_emissions/output/meta/flare_meta_2015.RData"
load(file.meta) # get parameters delta, etta and gauge pressure

file.emis <- "../Step_3_integration/output/flare.average.2015.RData"
load(file.emis) # get emission data

# data processing
n.flares <- dim(flare.average)[1]
n.spec   <- 4 # number of species (CO, SO2, NO, NO2), you can add more
lon           <- format(flare.average[,which(colnames(flare.average)=="lon")],digits=1,scientific=FALSE)          # deg
lat           <- format(flare.average[,which(colnames(flare.average)=="lat")],digits=1,scientific=FALSE)          # deg
source.height <- sprintf("%3.1f",array(30,dim=n.flares))                                                          # m
volume.stream <- format(flare.average[,which(colnames(flare.average)=="VOLSTREAM")],digits=5,scientific=FALSE)    # m3 s-1
source.temp   <- format(flare.average[,which(colnames(flare.average)=="SOURCETEMP")],digits=5,scientific=FALSE)   # K
heat.flow     <- format(flare.average[,which(colnames(flare.average)=="RADHEAT")],digits=5,scientific=FALSE)      # MW
emis.co       <- format(flare.average[,which(colnames(flare.average)=="CO")],digits=5,scientific=FALSE)           # kg h-1
emis.so2      <- format(flare.average[,which(colnames(flare.average)=="SO2")] ,digits=5,scientific=FALSE)         # kg h-1
emis.no       <- format(flare.average[,which(colnames(flare.average)=="NO")] ,digits=5,scientific=FALSE)          # kg h-1
emis.no2      <- format(flare.average[,which(colnames(flare.average)=="NO2")],digits=5,scientific=FALSE)          # kg h-1

# prepare table structure (complete table with full information)
spec.name.f    <- c("species",rep("CO",n.flares),rep("SO2",n.flares),rep("NO",n.flares),rep("NO2",n.flares))
lon.f          <- c("lon",rep(lon,n.spec))
lat.f          <- c("lat",rep(lat,n.spec))
spec.f         <- c("emission",emis.co,emis.so2,emis.no,emis.no2)
source.height.f<- c("sourceheight",rep(source.height,n.spec))
volume.stream.f<- c("volstream",rep(volume.stream,n.spec))
source.temp.f  <- c("sourcetemp",rep(source.temp,n.spec))
heat.flow.f    <- c("heatflow",rep(heat.flow,n.spec))
 flare.table.full <- cbind(spec.name.f,lon.f,lat.f,spec.f,source.height.f,volume.stream.f,source.temp.f,heat.flow.f)

# prepare table structure (table with reduced information, so that COSMO-ART uses the VIIRS heat.flow instead of an internal
# calculation via source.temp and heat.flow)
spec.name.c   <- spec.name.f
lon.c         <- lon.f
lat.c         <- lat.f
spec.c        <- spec.f
source.height.c <- source.height.f
volume.stream.c <- c("volstream",rep(sprintf("%4.1f",array(-999,dim=n.flares)),n.spec))
source.temp.c   <- c("sourcetemp",rep(sprintf("%4.1f",array(-999,dim=n.flares)),n.spec))
heat.flow.c     <- heat.flow.f
flare.table.cosmoart <- cbind(spec.name.c,lon.c,lat.c,spec.c,source.height.c,volume.stream.c,source.temp.c,heat.flow.c)

write.table(flare.table.cosmoart,sep=" ",row.names=FALSE,col.names=FALSE,
            file="./output/point.dat", quote=FALSE)

if(plot.quicklook){
tab <- read.table("./output/point.dat",skip=2)
load("../Step_2_calc_emissions/flare.grid.RData")
ie_tot <- length(seq(startlon,endlon,by=dlon))-1
je_tot <- length(seq(startlat,endlat,by=dlat))-1
lon <- seq(startlon,startlon+dlon*ie_tot,length=ie_tot)
lat <- seq(startlat,startlat+dlat*je_tot,length=je_tot)

CO <- array(NA,dim=c(length(lon),length(lat)))
for (i in 1:(dim(tab)[1])){
  if(tab[i,1]=="CO"){ CO[tab[i,2],tab[i,3]] <- tab[i,4]} 
}
image.plot(lon,lat,CO/1000,xlim=c(-10,15),ylim=c(-10,10),main="CO emission (t h-1) for 2015 (TP15)",las=1,col=tim.colors(20))
map("world",add=TRUE)
grid()
}

print("<R Script 4/4 - write files for cosmoart> complete.")
print("################################################################")
print("R package: <Creating a gas flaring emission dataset> completed.")
print("################################################################")
