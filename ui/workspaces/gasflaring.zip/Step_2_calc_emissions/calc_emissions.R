########################################################################
# Creating a gas flaring emission dataset
# R Script 2/4 - calculate emissions
# Konrad Deetz
# 30 August, 2016
# linked to the publication of Deetz and Vogel (2016)
########################################################################

# Before you start this script you have to define the grid on which
# you want to calculate the emissions (see below). Finally every flare has no longer
# the lon/lat specification from VIIRS but a grid box number according
# to the predefined grid. 
# (Within Step 3 (R Script 3/4 - averaging) all flare emissions of one grid
# box per day are summed up to finally have one huge flare per box. Then these
# "box flare" emissions are averaged over the whole period to get the climatology.
#
# Additionally, you have to make sure that you have information about the 
# natural gas composition of your research domain. This script includes 
# measurements from the Niger Delta (Nigeria) from Sonibare and Akeredolu
# (2004). The data output of this script is given in a special format 
# according to the needs of the model COSMO-ART (Vogel et al., 2009). Maybe 
# you have to change this according to your needs.
# The necessary functions are given in the directory <functions>.
 
# The equations defined in <FLARE_EMISSION_FUNCTIONS.R> and used in this 
# script are published in:
# Ismail, O., Umukoro, G., E., 2014: Modelling combustion reactions for 
# gas flaring and its resulting emissions", Journal of King Saud Universi-
# ty - Engineering Sciences.

# The natural gas composition is based measurements in the Niger Delta
# published in:
# Sonibare, J. A., Akeredolu, F., A., 2004: A theoretical prediction of
# non-methane gaseous emission from natural gas combustion. Energy
# Policy, Vol. 32, 1653-1665.

# It is strongly recommended to read the publication of Ismail and
# Umukoro (2014) to understand the calculations below).

# load libraries
# -

# clean up
rm(list=ls())

# units
# 1 Btu (British thermal unit) = 1055,05585262 J
# 1 scf (standard cubic feet)  = 1.19804 moles (unit of quantity not of volume)
# 1 mscfd (million scf per day)
# 1 lb (pound)                 = 0,453 592 37 kg   
# 1 psi                        = 6895 Pa

# Annotation: to calculate N2 according to Ismail and Umukoro (2014)
# please subtract the natural N2 part: e.g. for RT1
# RT.1.emissions[6]-j*M.N2

# data directories
dir.in      <- "../Step_1_preprocess_vnf_flare_rawdata/output/"
file.in     <- "vnf_flare_2015.RData"
outdir.meta <- paste("./output/meta/",sep="") #output directory for metadata (e.g. grid box location)
outdir.emis <- paste("./output/emis/",sep="") #output directory for emissions

# include functions for combustion calculations
source("./functions/FLARE_EMISSION_FUNCTIONS.R")

# include function for transforming regular coordinates to rotated coordinates
get.rotcoord <- dget("./functions/geocoord.to.rotcoord.R")

# Definition of your grid (in deg) for allocating the flares - COSMO-ART uses a rotated
# grid, therefore here we have the possibility to create a rotated grid here
# (if you need an unrotated (regular) grid, please use pollon=180, pollat=90).
pollon   <- 180.0   # lon coord of rotated pole    
pollat   <- 90.0    # lat coord of rotated pole    
polgam   <- 0.0     
startlon <- -10.0   # minimal lon
startlat <- -10.0   # minimal lat 
endlon   <- 15.0    # maximal lon
endlat   <- 10.0    # maximal lat
dlon     <- 0.25    # lon mesh size
dlat     <- 0.25    # lat mesh size
save(pollon,pollat,polgam,startlon,startlat,endlon,endlat,dlon,dlat,file="flare.grid.RData")

# parameters in Ismail and Umukoro (2014)
etta  <- 0.8  # combustion efficiency                         # -   
delta <- 0.95 # excess or deficiency of combustion air        # -

# additional parameter
gauge <- 5   # gauge pressure within the flare               # psi

# Stop if negative emissions occur (TRUE) or simply set these values to zero (FALSE)?
lcheck.emis <- TRUE
 
# load file
# ======================================================================
load(paste(dir.in,file.in,sep=""))

# get the flare information
lon      <- FLARE.DATA[,which(colnames(FLARE.DATA)=="lon")]    # deg
lat      <- FLARE.DATA[,which(colnames(FLARE.DATA)=="lat")]    # deg
s.temp   <- FLARE.DATA[,which(colnames(FLARE.DATA)=="temp.s")] # K
r.heat   <- FLARE.DATA[,which(colnames(FLARE.DATA)=="rh")]     # MW
n.flares <- dim(FLARE.DATA)[1]
date     <- substr(file.in,start=11,stop=14)
print(paste("proceed: ",date,sep=""))

#########################################################################
# Calculation of flaring emissions according to Ismail and Umukoro (2014)
# by using the natural gas composition of Sonibare and Akeredolu (2004)
#########################################################################

print("######################################")
print("Setup for flaring emission calculation")
print("######################################")

calcbase <- "Ismail and Umukoro (2014)"
print(paste("Combustion calculation theory based on      : ",calcbase,sep=""))

# a) natural gas composition
# ===========================================
database <- "Sonibare and Akeredolu (2004)"
print(paste("THC data based on                           : ",database,sep=""))

# total hydrocarbon (THC) [%]
#                                CH4      C2H6    C3H8          C4H10               C5H12        C6H14                  
#                                Methane  Ethane  Propane N-butane+I-butane  N-pentane+I-pentane hexane
#                                                         
beta.sonibare.and.aceredolu <- c(78.473,   6.16,   5.496,   2.3671+2.825,       2.8162+1.1367,   0.356)
beta <- beta.sonibare.and.aceredolu/100 # (%/100)

# stoichometric coefficient of CO2 (%/100)
a.sonibare.and.aceredolu <- 0.305/100
a <- a.sonibare.and.aceredolu

# stoichometric coefficient of N2 (%/100)
j.sonibare.and.aceredolu <- 0.06/100
j <- j.sonibare.and.aceredolu

# stoichometric coefficient of H2S (%/100) 
m.sonibare.and.aceredolu <- 0.005/100
m <- m.sonibare.and.aceredolu


# b) general parameters
# ===========================================
# 1. combustion efficiency ("tuning parameter")
print(paste("etta (combustion efficiency)                = ",etta,sep=""))

# 2. total hydrocarbon
# 2.1 Carbon
x <- calc.x(beta)
    
# 2.2 Hydrogen
y <- calc.y(beta)
 
# 3. percentage excess/deficiency of combustion air ("tuning parameter")
print(paste("delta (excess/deficiency of combustion air) = ",delta,sep=""))

# 4. parameter depending on the percentage excess/deficiency of combustion air 
# (z=4 for complete combustion)
z <- calc.z(x,y,delta)

# 5. Air-fuel-ratio (comparable with literature)
AFR <- calc.AFR(x,y,z)

# 6. air
# 6.1 stoichometric coefficient of air in combustion (unknown)
b <- calc.b(x,y,z)

# 6.2 stoichometric coefficient of air for complete combustion (k=b for z=4)
k <- calc.k(x,y)

# 7. stoichometric coefficient for the amount of excess oxygen in product of combustion
d <- calc.d(x,y,z,etta)


# c) reaction types
# ===========================================
#        RT1         RT2             RT3             RT4         RT5      RT6
# SO2     -           x               -               x           -        x
# NO      -           -               x               x           x        x
# NO2     -           -               -               -           x        x
#     T<=1200K 1200K<=T<=1600K 1200K<=T<=1600K 1200K<=T<=1600K T>=1600K T>=1600K


# Reaction type 1: Incomplete combustion of "sweet gas" without the formation of NOx 

  RT.1.emissions <- RT.1(x,y,z,a,m,b,d,j,etta,beta)


# Reaction type 2: Incomplete combustion of "sour gas" without the formation of NOx 

  RT.2.emissions <- RT.2(x,y,z,a,m,b,d,j,etta,beta)


# Reaction type 3: Incomplete combustion of "sweet gas" with formation of NOx (only NO) 

  RT.3.emissions <- RT.3(x,y,z,a,m,b,d,j,etta,beta)


# Reaction type 4: Incomplete combustion of "sour gas" with formation of NOx (only NO) 

  RT.4.emissions <- RT.4(x,y,z,a,m,b,d,j,etta,beta)


# Reaction type 5: Incomplete combustion of "sweet gas" with formation of NOx (NO and NO2) 

  RT.5.emissions <- RT.5(x,y,z,a,m,b,d,j,etta,beta)


# Reaction type 6: Incomplete combustion of "sour gas" with formation of NOx (NO and NO2) 

  RT.6.emissions <- RT.6(x,y,z,a,m,b,d,j,etta,beta)


#########################################################################
# Calculate flaring emission rates
#########################################################################

# result array
FLARE.EMISSION <- array(NA,dim=c(n.flares,14))

# loop over gauge pressure of fuel gas
print(paste("gauge pressure of fuel gas                  = ",gauge," psi (",gauge*0.06895," bar)",sep=""))

# loop over all flares to calculate the emission rates according
# to the VIIRS Nightfire observations
for (iflare in 1:n.flares){

# a) VIIRS Nightfire observation data
# ===========================================
T.EXIT   <- s.temp[iflare] # K  (VIIRS)
RAD.HEAT <- r.heat[iflare] # MW (VIIRS)

# b) combustion theory (Ismail and Umukoro, 2014)
# ===========================================
# no NOx
if (T.EXIT <= 1200){
composition <- RT.2.emissions

# only NO
}else if(T.EXIT > 1200 & T.EXIT <= 1600){
composition <- RT.4.emissions

# NO and NO2
}else if(T.EXIT > 1600){
composition <- RT.6.emissions

}

# c) calculate volume stream according to
# Technische Anleitung zur Reinhaltung der Luft
# 1986 (equation 22)
# ===========================================
# Volume stream of the exhaust gas in standard condition R (m3 s-1) =
# Heat stream M (MW) / ((1.36*10^-3) * (exhaust temperature T (K) - 283)) 
#
# After Guigard et al. (2000) only a fraction of the total reaction energy 
# is emitted as radiation. Only this fraction of heat radiated (f hereafter)
# is detected by VIIRS. We assume that the heat stream in equation 22 is equal
# to the total reaction energy. Therefore we multiply the radiant heat with
# 1/f to avoid an underestimation of the volume stream. We have determinded the
# value f=0.27 by averaging Guigard et al. (2000) Appendix 1 exept of 
# Cook et al. and Chamberlain. For the uncertainty accessment we have used 
# the upper and lower limit of f by adding and substracting the standard
# deviation (f_max=0.38, f_min=0.16).

f.guigard2000 <- 0.27
VOL.FLUX <- RAD.HEAT*(1/f.guigard2000) / (1.36 * 10^-3 * (T.EXIT-283)) # m3 s-1


# d) mass fractions of combustion species
# ===========================================
dist <- (composition/sum(composition)) # [0 1]

# e) molar mass for the fuel gas (in) 
# and the exhaust emissions (out)
# ===========================================
M.air     <- 0.0289644    # kg mol-1

M.fuel    <- M.CH4   * beta[1] + M.C2H6  * beta[2] + M.C3H8  * beta[3] + 
             M.C4H10 * beta[4] + M.C5H12 * beta[5] + M.C6H14 * beta[6] +
             M.CO2   * a       + M.N2    * j       + M.H2S   * m  
M.fuel    <- M.fuel / 1000  # kg mol-1

M.exhaust <- M.CO2 * dist[1] + M.H2O * dist[2] + M.CO  * dist[3] + 
             M.H2  * dist[4] + M.O2  * dist[5] + M.N2  * dist[6] + 
             M.SO2 * dist[7] + M.NO  * dist[8] + M.NO2 * dist[9] # g mol-1
M.exhaust <- M.exhaust / 1000 # kg mol-1

# f) gas constants
# ===========================================
R.ideal     <- 8.3144621            # J mol-1 K-1
R.s.air     <- R.ideal / M.air      # J kg-1 K-1
R.s.fuel    <- R.ideal / M.fuel     # J kg-1 K-1
R.s.exhaust <- R.ideal / M.exhaust  # J kg-1 K-1

# g) temperature and pressure
# ===========================================
# ambient pressure
p.ambient   <- 101325               # Pa

# Fuel gas pressure?
# 1. Single point flares can be designed without smoke suppression, or
# with steam- or air-assisted smoke-suppression equipment[...].This is
# the most common type of flare for onshore refining facilities that operate
# at low pressure (<10 psig) [Bader et al. (2011): American Institute of 
# Chemical Engineers (AIChE).]
# 2. Most subsonic-flare seal drums operate in the range of gauge pressure
# from 0 kPa to 34 kPa (0 psi to 5 psi) after "Review unit-wide impacts on 
# closed-drain drums"
psi.gauge   <- gauge                # Psi
p.gauge     <- psi.gauge * 6895     # Pa (1 psi = 6895 Pa)
p.fuel      <- p.ambient + p.gauge  # Pa

# temperature
T.ambient   <- 293.15               # K
T.exhaust   <- T.EXIT               # K

# h) gas density via ideal gas equation
# ===========================================
rho.fuel <- p.fuel / ((R.ideal/M.fuel) * T.ambient) # kg m-3

# i) distribute gas density to the combustion species fractions (Daltons Law)
# ===========================================
partial.density <- dist * rho.fuel  # kg m-3

# e) mass emission rates
# ===========================================
m.rate.s <- VOL.FLUX * partial.density # m3 s-1 * kg m-3 -> kg s-1 
m.rate.h <- m.rate.s * 60 * 60         # kg h-1 

FLARE.EMISSION[iflare,1]  <- lon[iflare]
FLARE.EMISSION[iflare,2]  <- lat[iflare]
FLARE.EMISSION[iflare,3]  <- s.temp[iflare]
FLARE.EMISSION[iflare,4]  <- RAD.HEAT
FLARE.EMISSION[iflare,5]  <- VOL.FLUX
FLARE.EMISSION[iflare,6]  <- m.rate.h[1]
FLARE.EMISSION[iflare,7]  <- m.rate.h[2]
FLARE.EMISSION[iflare,8]  <- m.rate.h[3]
FLARE.EMISSION[iflare,9]  <- m.rate.h[4]
FLARE.EMISSION[iflare,10] <- m.rate.h[5] 
FLARE.EMISSION[iflare,11] <- m.rate.h[6]
FLARE.EMISSION[iflare,12] <- m.rate.h[7]
FLARE.EMISSION[iflare,13] <- m.rate.h[8]
FLARE.EMISSION[iflare,14] <- m.rate.h[9]

colnames(FLARE.EMISSION) <- c("VIIRS-lon","VIIRS-lat","VIIRS-sourcetemp","VIIRS-radiantheat",
                              "VOL-Flux","CO2","H2O","CO","H2","O2","N2","SO2","NO","NO2")

} #iflare


#########################################################################
# Data formatting to allow import into COSMO-ART
#########################################################################

# a) geocoordinates to rotated coordinates and corresponding domain gridboxes
# ===========================================
rlon <- array(NA,dim=n.flares)
rlat <- array(NA,dim=n.flares)
blon <- array(NA,dim=n.flares)
blat <- array(NA,dim=n.flares)
bvert <- array(NA,dim=n.flares)
sourceheight <- array(NA,dim=n.flares)
  
for (iflare in 1:n.flares){
 # function for transforming geocoord to rotcoord and corresponding gridboxes

 rot.tmp <- get.rotcoord(lon[iflare],lat[iflare],pollon,pollat,polgam,startlon,startlat,dlon,dlat) 

 rlon[iflare]         <- rot.tmp[,1]
 rlat[iflare]         <- rot.tmp[,2]
 blon[iflare]         <- rot.tmp[,3]
 blat[iflare]         <- rot.tmp[,4]
 bvert[iflare]        <- 0
 sourceheight[iflare] <- 30.0 # assume a source height of 30m (typical flare stack height, replace this with real heights if available)

} #iflare

# b) output filename
# ===========================================
filename.meta  <- paste("Flaring_dacciwa_meta.txt",sep="")

if (etta==1 & delta==1) {
filename.emis  <- paste(outdir.emis,"flare_emis_",date,"_delta_",delta,".0_etta_",etta,".0_gaugepress_",gauge,"_psi.RData",sep="")
}else if (etta==1 & delta!=1) {
filename.emis  <- paste(outdir.emis,"flare_emis_",date,"_delta_",delta,"_etta_",etta,".0_gaugepress_",gauge,"_psi.RData",sep="")
}else if (etta!=1 & delta==1) {
filename.emis  <- paste(outdir.emis,"flare_emis_",date,"_delta_",delta,".0_etta_",etta,"_gaugepress_",gauge,"_psi.RData",sep="")
}else{
filename.emis  <- paste(outdir.emis,"flare_emis_",date,"_delta_",delta,"_etta_",etta,"_gaugepress_",gauge,"_psi.RData",sep="")
}

# c) save the METADATA
# ===========================================
n.species <- 4
meta    <- cbind(blon,blat,bvert,sourceheight,
                 FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="VOL-Flux")],
                 FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="VIIRS-radiantheat")],
                 FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="VIIRS-sourcetemp")])
colnames(meta) <- c("blon","blat","bvert","sourceheight (m)","VOL-Flux (m3 s-1)","VIIRS-radiantheat (MW)","VIIRS-sourcetemp (K)")

save(delta,etta,gauge,meta,file=paste(outdir.meta,"flare_meta_",date,".RData",sep=""))

# d) save the EMISDATA
# ===========================================
emis <- cbind(FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="CO")],
              FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="SO2")],
              FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="NO")],
              FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="NO2")],
              FLARE.EMISSION[,which(colnames(FLARE.EMISSION)=="CO2")]) 

colnames(emis) <- c("CO","SO2","NO","NO2","CO2")

# Look for negative emissions (could occur if a delta and etta parameter
# combination does not make sense). Set these values to zero.
if(length(which(emis<0))>0){
 if(lcheck.emis){
  print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  stop("Negative emissions occur in NO or NO2 (set to zero)! Please check your selection of <delta> and <etta>.")
  print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
 }else{
  print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
  print("Negative emissions occur in NO or NO2 (set to zero)! Please check your selection of <delta> and <etta>.")
  emis[emis<0]<-0
  print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
 } #lcheck.emis
} #emis>=0?
save(emis,file=filename.emis)

print("######################################")

print("<R Script 2/4 - calc emissions> complete.")
