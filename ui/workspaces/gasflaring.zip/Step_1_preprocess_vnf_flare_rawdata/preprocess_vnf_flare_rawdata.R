########################################################################
# Creating a gas flaring emission dataset
# R Script 1/4 - preprocess VNP_flare rawdata
# Konrad Deetz
# 30 August, 2016
# linked to the publication of Deetz and Vogel (2016)
########################################################################

# The rawdata is given by VIIRS Nightfire Nighttime Detection and Characterization of Combustion Sources
# (http://ngdc.noaa.gov/eog/viirs/download_viirs_fire.html).
# Flaring information was extracted and kindly provided by Dr. Mikhail Zhizhin (Earth Observation Group NOAA)
# as csv files for every flare of the countries Ivory Coast, Ghana, Togo, Benin, Nigeria, Cameroon, 
# Equatorial Guinea, Gabon, Rep. of the Congo, Dem. Rep. of the Congo and Angola
# for the time period 1 June - 31 July 2014 and 1 June - 31 July 2015.

# clean up
rm(list=ls())

# single timeseries files
file.list <- list.files("./VNF_flare_rawdata/")
file.list <- paste("./VNF_flare_rawdata/",file.list[grep("-timeseries.csv",file.list)],sep="")

print("please wait ...")
# define result arrays
#                                 flare             day properties
FLARE.DATA.2014 <- array(NA,dim=c(length(file.list),61 ,4         ))
FLARE.DATA.2015 <- array(NA,dim=c(length(file.list),61 ,4         ))

# date array
date.2014 <- c(paste(seq(1,30,by=1),"-Jun-2014",sep=""),paste(seq(1,31,by=1),"-Jul-2014",sep=""))
date.2015 <- c(paste(seq(1,30,by=1),"-Jun-2015",sep=""),paste(seq(1,31,by=1),"-Jul-2015",sep=""))

# loop over all timeseries files
for (ifile in 1:length(file.list)){

# read table
tab <- read.csv2(file.list[ifile],sep=",",dec=".")

# define column names
colnames(tab) <- c("id_Flare","Lat_Flare","Lon_Flare","Lat_GMTCO","Lon_GMTCO",
"Date","Temp_BB","ESF_BB","RHI","RH","RH_prime","Flow_Rate","Area_BB","Cloud_Mask",
"QF_Detect","QF_DB","COT_IVCOP","SATZ_GMTCO","Ellipse_A","Ellipse_B","Rad_M07",
"Rad_M10","Sample_M10","Line_M10","id_Aggregate")

# loop over all days (1 June to 31 July)
for(iday in 1:61){

# find current date
day.2014 <- date.2014[iday]
index.2014 <- grep(day.2014,tab[,6])[1]
day.2015 <- date.2015[iday]
index.2015 <- grep(day.2015,tab[,6])[1]

# select data for current date in 2014
if(!is.na(index.2014)){
FLARE.DATA.2014[ifile,iday,1] <- as.numeric(tab[index.2014,which(colnames(tab)=="Lon_Flare")])
FLARE.DATA.2014[ifile,iday,2] <- as.numeric(tab[index.2014,which(colnames(tab)=="Lat_Flare")])
FLARE.DATA.2014[ifile,iday,3] <- as.numeric(tab[index.2014,which(colnames(tab)=="Temp_BB")])
FLARE.DATA.2014[ifile,iday,4] <- as.numeric(tab[index.2014,which(colnames(tab)=="RH_prime")])
}else{
FLARE.DATA.2014[ifile,iday,1] <- NA
FLARE.DATA.2014[ifile,iday,2] <- NA
FLARE.DATA.2014[ifile,iday,3] <- NA
FLARE.DATA.2014[ifile,iday,4] <- NA
}

# select data for current date in 2015
if(!is.na(index.2015)){
FLARE.DATA.2015[ifile,iday,1] <- as.numeric(tab[index.2015,which(colnames(tab)=="Lon_Flare")])
FLARE.DATA.2015[ifile,iday,2] <- as.numeric(tab[index.2015,which(colnames(tab)=="Lat_Flare")])
FLARE.DATA.2015[ifile,iday,3] <- as.numeric(tab[index.2015,which(colnames(tab)=="Temp_BB")])
FLARE.DATA.2015[ifile,iday,4] <- as.numeric(tab[index.2015,which(colnames(tab)=="RH_prime")])
}else{
FLARE.DATA.2015[ifile,iday,1] <- NA
FLARE.DATA.2015[ifile,iday,2] <- NA
FLARE.DATA.2015[ifile,iday,3] <- NA
FLARE.DATA.2015[ifile,iday,4] <- NA
}
}
}

# set missing values to NA
FLARE.DATA.2014[FLARE.DATA.2014==999999] <- NA
FLARE.DATA.2015[FLARE.DATA.2015==999999] <- NA

# flare positions
lon.2014 <- FLARE.DATA.2014[,1,1]
lat.2014 <- FLARE.DATA.2014[,1,2]
lon.2015 <- FLARE.DATA.2015[,1,1]
lat.2015 <- FLARE.DATA.2015[,1,2]

# calculate mean over TP14 and TP15 for every single flare (for E_clim)
FLARE.DATA.MEAN.2014 <- array(NA,dim=c(length(file.list),4))
FLARE.DATA.MEAN.2015 <- array(NA,dim=c(length(file.list),4))

# loop over every flare
for(iflare in 1:length(file.list)){
FLARE.DATA.MEAN.2014[iflare,1] <- lon.2014[iflare]
FLARE.DATA.MEAN.2014[iflare,2] <- lat.2014[iflare]
FLARE.DATA.MEAN.2014[iflare,3] <- mean(FLARE.DATA.2014[iflare,,3],na.rm=TRUE)
FLARE.DATA.MEAN.2014[iflare,4] <- mean(FLARE.DATA.2014[iflare,,4],na.rm=TRUE)

FLARE.DATA.MEAN.2015[iflare,1] <- lon.2015[iflare]
FLARE.DATA.MEAN.2015[iflare,2] <- lat.2015[iflare]
FLARE.DATA.MEAN.2015[iflare,3] <- mean(FLARE.DATA.2015[iflare,,3],na.rm=TRUE)
FLARE.DATA.MEAN.2015[iflare,4] <- mean(FLARE.DATA.2015[iflare,,4],na.rm=TRUE)
}

# remove flares which are not at least once active in TP14 or TP15
index.2014.T <- which(!is.na(FLARE.DATA.MEAN.2014[,3]))
index.2015.T <- which(!is.na(FLARE.DATA.MEAN.2015[,3]))
FLARE.DATA.MEAN.2014 <- FLARE.DATA.MEAN.2014[index.2014.T,c(1:4)]
FLARE.DATA.MEAN.2015 <- FLARE.DATA.MEAN.2015[index.2015.T,c(1:4)]

# define column names for the result arrays
colnames(FLARE.DATA.MEAN.2014) <- c("lon","lat","temp.s","rh")
colnames(FLARE.DATA.MEAN.2015) <- c("lon","lat","temp.s","rh")

# save the data in R binary format
FLARE.DATA <- FLARE.DATA.MEAN.2014
save(FLARE.DATA,file="./output/vnf_flare_2014.RData")
FLARE.DATA <- FLARE.DATA.MEAN.2015
save(FLARE.DATA,file="./output/vnf_flare_2015.RData")

print("<R Script 1/4 - preprocess VNP_flare rawdata> complete.")



