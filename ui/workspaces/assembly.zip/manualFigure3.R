library(STEPCAM)
library(MCMCglmm)
library(vegan)
library(rgdal)
library(raster)
library(gdistance)
library(compositions)
library(gtools)

Run <- 3

if(Run == 3){
  OS <- 0
}

if(Run %in% c(2,3) | OS != 0 ){ 
  GC <- readRDS("SpatiallyConstrainedClustering.rds")
}

nameGeoCluster <- function(Loc, Groups){
  Group <- rep(NA, nrow(Loc))
  Ord <- order(boxplot(Loc$Depth ~ as.factor(Groups), 
                       plot = FALSE)$stat[3,], decreasing = FALSE)
  if(max(Loc$Northings[Groups == Ord[1]]) < 4550000){
    Group[Groups == Ord[1]] <- "1 SE upper littoral zone 1"
  }
  if(max(Loc$Northings[Groups == Ord[1]]) >= 4550000){
    Group[Groups == Ord[1]] <- "2 SE upper littoral zone 2"
  }  
  if(max(Loc$Northings[Groups == Ord[2]]) < 4550000){
    Group[Groups == Ord[2]] <- "1 SE upper littoral zone 1"
  }
  if(max(Loc$Northings[Groups == Ord[2]]) >= 4550000){
    Group[Groups == Ord[2]] <- "2 SE upper littoral zone 2"
  } 
  Group[Groups == Ord[3]] <- "3 SE upper littoral zone 3"
  Group[Groups == Ord[4]] <- "4 Non-SE upper littoral"
  Group[Groups == Ord[5]] <- "5 lower littoral"
  Group[Groups == Ord[6]] <- "6 upper sublittoral"
  Group[Groups == Ord[7]] <- "7 lower sublittoral"
  return(Group)
}

Localities <- read.csv("Localities.csv", sep = ",", header = TRUE, row.names = 1)
EcoZones <- lapply(GC, function(x) nameGeoCluster(Loc = Localities, Groups = x$groups))
G <- 6
Localities <- data.frame(Localities, GeoClus = EcoZones[[G]])

Ohrid0mShp <- readOGR(dsn = getwd(), layer="0m")
layout(matrix(1:3, nc = 3, nr = 1))
value=0.1 
par(las = 2, mar = c(8.1, 4.5, 0.1, 0.1))
boxplot(Localities[Localities$GeoClus == "1 SE upper littoral zone 1", "Depth"]+value, # 
        Localities[Localities$GeoClus == "2 SE upper littoral zone 2", "Depth"]+value, 
        Localities[Localities$GeoClus == "3 SE upper littoral zone 3", "Depth"]+value, 
        Localities[Localities$GeoClus == "4 Non-SE upper littoral", "Depth"]+value,
        Localities[Localities$GeoClus == "5 lower littoral", "Depth"]+value,
        Localities[Localities$GeoClus == "6 upper sublittoral", "Depth"]+value,
        Localities[Localities$GeoClus == "7 lower sublittoral", "Depth"]+value, # 4
        col = c("#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"), 
        names = c("SE upper littoral\nzone 1","SE upper littoral\nzone 2","SE upper littoral\nzone 3",
                  "Non-SE upper\nlittoral","lower\nlittoral","upper\nsublittoral", "lower\nsublittoral"),
        log = "y", ylab = "Depth (m)", ylim = c(55,0.1))
mtext("(a)", side = 2, line = 3.1, at = 0.085, cex = 1.4)
par(las = 2, mar = c(0.1, 0.1, 0.1, 0.1))
plot(Ohrid0mShp, col = "grey90")

points(Localities[Localities$GeoClus == "4 Non-SE upper littoral", 4:5], 
       pch = 21, cex = 1.5, bg = "#f7f7f7")
points(Localities[Localities$GeoClus == "3 SE upper littoral zone 3", 4:5], 
       pch = 21, cex = 1.5, bg = "#fddbc7")
points(Localities[Localities$GeoClus == "2 SE upper littoral zone 2", 4:5], 
       pch = 21, cex = 1.5, bg = "#ef8a62")
points(Localities[Localities$GeoClus == "1 SE upper littoral zone 1", 4:5], 
       pch = 21, cex = 1.5, bg = "#b2182b")
text(x = par("usr")[1] + par("usr")[1]/500, y = par("usr")[4] - par("usr")[4]/7000, 
     labels = "(b)", cex = 2)
plot(Ohrid0mShp, col = "grey90")
points(Localities[Localities$GeoClus == "5 lower littoral", 4:5], 
       pch = 21, cex = 1.5, bg = "#d1e5f0")
points(Localities[Localities$GeoClus == "6 upper sublittoral", 4:5], 
       pch = 21, cex = 1.5, bg = "#67a9cf")
points(Localities[Localities$GeoClus == "7 lower sublittoral", 4:5], 
       pch = 21, cex = 1.5, bg = "#2166ac")
text(x = par("usr")[1] + par("usr")[1]/500, y = par("usr")[4] - par("usr")[4]/7000, 
     labels = "(c)", cex = 2)