library(STEPCAM)
library(MCMCglmm)
library(vegan)
library(rgdal)
library(raster)
library(gdistance)
library(compositions)
library(gtools)

Run <- 3

if(Run == 3){
  OS <- 0
}

if(Run == 3){
  Res <- read.csv("StepcamResultHauffe.csv", sep = ",", header = TRUE, row.names = 1)
}

layout(matrix(1:3, nc = 3, nr = 1))
par(las = 2, mar = c(8.1, 4.1, 0.1, 0.1))
boxplot(Dispersal ~ GeoClus, data = Res, 
        #col = c("magenta", "red4", "green4", "cyan", "cornflowerblue", "blue", "blue4"), 
        col = c("#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"), 
        names = c("SE upper littoral\nzone 1","SE upper littoral\nzone 2","SE upper littoral\nzone 3",
                  "Non-SE upper\nlittoral","lower\nlittoral","upper\nsublittoral", "lower\nsublittoral"),
        ylab = "Dispersal limitation importance", ylim = c(0,1))
mtext("(a)", side = 2, line = 2.5, at = 1, cex = 1.4)
boxplot(Environment ~ GeoClus, data = Res, 
        col = c("#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"),  
        names = c("SE upper littoral\nzone 1","SE upper littoral\nzone 2","SE upper littoral\nzone 3",
                  "Non-SE upper\nlittoral","lower\nlittoral","upper\nsublittoral", "lower\nsublittoral"),
        ylab = "Environmental filtering importance", ylim = c(0,1))
mtext("(b)", side = 2, line = 2.5, at = 1, cex = 1.4)
boxplot(Interaction ~ GeoClus, data = Res, 
        col = c("#b2182b", "#ef8a62", "#fddbc7", "#f7f7f7", "#d1e5f0", "#67a9cf", "#2166ac"),  
        names = c("SE upper littoral\nzone 1","SE upper littoral\nzone 2","SE upper littoral\nzone 3",
                  "Non-SE upper\nlittoral","lower\nlittoral","upper\nsublittoral", "lower\nsublittoral"),
        ylab = "Species interaction importance", ylim = c(0,1))
mtext("(c)", side = 2, line = 2.5, at = 1, cex = 1.4)