library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
brightblue <- rgb(102, 204, 255, max = 255)
ozstars <- make_stars(ozm, "time", "value")
one <- subset(ozstars, lat == max(lat) & long == min(long))
theta <- seq(0, 2 * pi, length = 100)
circle <- data.frame(x = sin(theta), y = cos(theta))
year_theta <- seq(0, 2 * pi, length = 7)[-7]
year <- data.frame(x = sin(year_theta), y = cos(year_theta))
ggplot(one, aes(x, y)) + 
  geom_polygon(data = circle, fill = NA, colour = "grey70") +
  geom_segment(aes(xend = 0, yend = 0), data = year, colour = "grey70") +
  geom_path(fill = NA, colour = "black") +
  coord_equal() + 
  annotate("point", 0, 0, colour = "grey70", size = 4) +
  geom_point(subset = .(time == 0), colour = brightblue, size = 3) +
  xlab(NULL) + ylab(NULL)