library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
brightblue <- rgb(102, 204, 255, max = 255)
value <- plyr::ozone[1, 1, ]
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
library("MASS")
deseasf <- function(value) rlm(value ~ month - 1, maxit = 50)
models <- alply(plyr::ozone, 1:2, deseasf)
coefs <- laply(models, coef)
dimnames(coefs)[[3]] <- month.abbr
names(dimnames(coefs))[3] <- "month"
coefs_df <- melt(coefs)
coefs_df <- ddply(coefs_df, .(lat, long), transform, 
                  avg = mean(value),
                  std = value / max(value)
)
levels(coefs_df$month) <- month.abbr
coef_limits <- range(coefs_df$value)
monthsurface <- function(mon) {
  df <- subset(coefs_df, month == mon)
  qplot(long, lat, data = df, fill = value, geom="tile") + 
    scale_fill_gradient(limits = coef_limits, 
                        low = brightblue, high = "yellow") + 
    map + theme(aspect.ratio = 1)
}
month="Jul"
plot(monthsurface(month))