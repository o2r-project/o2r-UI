library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
value <- plyr::ozone[1, 1, ]
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
year <- rep(1:6, each = 12)
graphtype="line"
plot(qplot(month, value, geom=graphtype, group = year))