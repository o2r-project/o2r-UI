library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
baberuth <- subset(baseball, id == "ruthba01")
baberuth <- transform(baberuth, cyear = year - min(year) + 1)
baseball <- ddply(baseball, .(id), transform, 
                  cyear = year - min(year) + 1)
baseball <- subset(baseball, ab >= 10)
xlim <- range(baseball$cyear, na.rm=TRUE)
model <- function(df) {
  lm(rbi / ab ~ cyear, data=df)
}
bmodels <- dlply(baseball, .(id), model)
rsq <- function(x) summary(x)$r.squared
bcoefs <- ldply(bmodels, function(x) c(coef(x), rsquare = rsq(x)))
names(bcoefs)[2:3] <- c("intercept", "slope")
ggplot(bcoefs, aes(slope, intercept)) + 
  geom_point(aes(size = rsquare), alpha = 0.5) +
  geom_vline(xintercept = 0, size=0.5, colour="grey50") + 
  geom_hline(yintercept = 0, size = 0.5, colour="grey50") + 
  scale_size_area(limits = c(0.5, 3), breaks = c(0, 0.25, 0.5, 0.75, 1))