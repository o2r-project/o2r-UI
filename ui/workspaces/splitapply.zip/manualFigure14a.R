library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
value <- plyr::ozone[1, 1, ]
time <- 1:72 / 12
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
library("MASS")
deseas1 <- rlm(value ~ month - 1)
plot(qplot(time, resid(deseas1), geom="line") + geom_hline(colour="grey70"))