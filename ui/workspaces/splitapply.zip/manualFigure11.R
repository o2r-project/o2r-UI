library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
ozstars <- make_stars(ozm, "time", "value")
res <- 1.2
ggplot(ozstars, aes(x = long + res * x, y = lat + res * y)) + map +
  geom_path(aes(group = interaction(long, lat)), fill=NA, colour="grey50")