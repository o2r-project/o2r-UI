library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
value <- plyr::ozone[1, 1, ]
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
library("MASS")
deseas1 <- rlm(value ~ month - 1)
graphtype="line"
plot(qplot(levels(month), unname(coef(deseas1)), geom=graphtype, group = 1) + geom_hline(colour="grey70"))