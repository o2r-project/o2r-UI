library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
deseasf <- function(value) rlm(value ~ month - 1, maxit = 50)
models <- alply(plyr::ozone, 1:2, deseasf)
deseas <- laply(models, resid)
dimnames(deseas)[[3]] <- 1:72
names(dimnames(deseas))[3] <- "time"
deseas_df <- melt(deseas)
deseas_stars <- make_stars(deseas_df, "time", "value")
res <- 1.2
ggplot(deseas_stars, aes(x = long + res * x, y = lat + res * y)) +
  map + geom_path(aes(group = interaction(long, lat)), 
                  colour="grey50", fill=NA) +
  theme(aspect.ratio = 1)