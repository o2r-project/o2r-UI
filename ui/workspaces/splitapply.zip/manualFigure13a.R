library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
value <- plyr::ozone[1, 1, ]
time <- 1:72 / 12
plot(qplot(time, value, geom="line"))