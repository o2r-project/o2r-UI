library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
brightblue <- rgb(102, 204, 255, max = 255)
ozstars <- make_stars(ozm, "time", "value")
one <- subset(ozstars, lat == max(lat) & long == min(long))
ggplot(one, aes(time, value)) + 
  geom_hline(yintercept = c(0, 1), colour = "grey70") + 
  geom_vline(xintercept = seq(0, 1, length = 7), colour = "grey70") +
  geom_line() + 
  geom_point(subset = .(time == 0), colour = brightblue, size = 4) +
  xlab(NULL) + ylab(NULL)
