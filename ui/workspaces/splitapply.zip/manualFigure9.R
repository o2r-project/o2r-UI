library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
playerID="ruthba01" #ruthba01, orourji01
baberuth <- subset(baseball, id == playerID)
baberuth <- transform(baberuth, cyear = year - min(year) + 1)
baseball <- ddply(baseball, .(id), transform, 
                  cyear = year - min(year) + 1)
baseball <- subset(baseball, ab >= 25)
model <- function(df) {
  lm(rbi / ab ~ cyear, data=df)
}
model(baberuth)
bmodels <- dlply(baseball, .(id), model)
rsq <- function(x) summary(x)$r.squared
bcoefs <- ldply(bmodels, function(x) c(coef(x), rsquare = rsq(x)))
names(bcoefs)[2:3] <- c("intercept", "slope")
binwidthVal = newValue
plot(qplot(rsquare, data=bcoefs, geom="histogram", binwidth=binwidthVal))