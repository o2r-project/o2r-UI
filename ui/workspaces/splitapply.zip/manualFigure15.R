library("reshape")
library("ggplot2")
library("plyr")
options(digits = 3)
options(prompt = "R> ")
source("ozone-map.R")
brightblue <- rgb(102, 204, 255, max = 255)
value <- plyr::ozone[1, 1, ]
month.abbr <- c("Jan", "Feb", "Mar", "Apr", "May", 
                "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
month <- factor(rep(month.abbr, length = 72), levels = month.abbr)
deseasf <- function(value) rlm(value ~ month - 1, maxit = 50)
models <- alply(plyr::ozone, 1:2, deseasf)
coefs <- laply(models, coef)
dimnames(coefs)[[3]] <- month.abbr
names(dimnames(coefs))[3] <- "month"
coefs_df <- melt(coefs)
coefs_df <- ddply(coefs_df, .(lat, long), transform, 
                  avg = mean(value),
                  std = value / max(value)
)
levels(coefs_df$month) <- month.abbr
coef_stars <- make_stars(coefs_df, "month", "std")
res <- 1.2
ggplot(coef_stars, aes(x = long + res * x, y = lat + res * y, fill=avg)) +
  map + geom_polygon(aes(group = interaction(long, lat)), colour="grey50") +
  scale_fill_gradient(low = brightblue, high = "yellow") + 
  theme(aspect.ratio = 1)